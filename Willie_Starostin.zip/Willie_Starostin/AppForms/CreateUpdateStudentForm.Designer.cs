﻿namespace Willie_Starostin.AppForms
{
    partial class CreateUpdateStudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dateLabel;
            System.Windows.Forms.Label fIOLabel;
            System.Windows.Forms.Label emailLabel;
            System.Windows.Forms.Label cardLabel;
            System.Windows.Forms.Label heightLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label mainHandIDLabel;
            System.Windows.Forms.Label genderIDLabel;
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.genderIDComboBox = new System.Windows.Forms.ComboBox();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.willie_StarostinDataSet = new Willie_Starostin.Willie_StarostinDataSet();
            this.genderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mainHandIDComboBox = new System.Windows.Forms.ComboBox();
            this.handBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.phoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.SaveAttentionBackground = new System.Windows.Forms.Button();
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.fIOTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.cardTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.studentTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.StudentTableAdapter();
            this.tableAdapterManager = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.TableAdapterManager();
            this.genderTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.GenderTableAdapter();
            this.handTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.HandTableAdapter();
            dateLabel = new System.Windows.Forms.Label();
            fIOLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            cardLabel = new System.Windows.Forms.Label();
            heightLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            mainHandIDLabel = new System.Windows.Forms.Label();
            genderIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.willie_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.genderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.handBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dateLabel
            // 
            dateLabel.AutoSize = true;
            dateLabel.Location = new System.Drawing.Point(3, 39);
            dateLabel.Name = "dateLabel";
            dateLabel.Size = new System.Drawing.Size(94, 13);
            dateLabel.TabIndex = 0;
            dateLabel.Text = "Дата вступления";
            // 
            // fIOLabel
            // 
            fIOLabel.AutoSize = true;
            fIOLabel.Location = new System.Drawing.Point(3, 64);
            fIOLabel.Name = "fIOLabel";
            fIOLabel.Size = new System.Drawing.Size(68, 13);
            fIOLabel.TabIndex = 2;
            fIOLabel.Text = "Полное имя";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(3, 116);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(32, 13);
            emailLabel.TabIndex = 6;
            emailLabel.Text = "Email";
            // 
            // cardLabel
            // 
            cardLabel.AutoSize = true;
            cardLabel.Location = new System.Drawing.Point(3, 142);
            cardLabel.Name = "cardLabel";
            cardLabel.Size = new System.Drawing.Size(75, 13);
            cardLabel.TabIndex = 8;
            cardLabel.Text = "Номер карты";
            // 
            // heightLabel
            // 
            heightLabel.AutoSize = true;
            heightLabel.Location = new System.Drawing.Point(3, 168);
            heightLabel.Name = "heightLabel";
            heightLabel.Size = new System.Drawing.Size(31, 13);
            heightLabel.TabIndex = 10;
            heightLabel.Text = "Рост";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(3, 90);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(52, 13);
            phoneLabel.TabIndex = 17;
            phoneLabel.Text = "Телефон";
            // 
            // mainHandIDLabel
            // 
            mainHandIDLabel.AutoSize = true;
            mainHandIDLabel.Location = new System.Drawing.Point(3, 194);
            mainHandIDLabel.Name = "mainHandIDLabel";
            mainHandIDLabel.Size = new System.Drawing.Size(118, 13);
            mainHandIDLabel.TabIndex = 18;
            mainHandIDLabel.Text = "Преобладающая рука";
            // 
            // genderIDLabel
            // 
            genderIDLabel.AutoSize = true;
            genderIDLabel.Location = new System.Drawing.Point(3, 221);
            genderIDLabel.Name = "genderIDLabel";
            genderIDLabel.Size = new System.Drawing.Size(27, 13);
            genderIDLabel.TabIndex = 19;
            genderIDLabel.Text = "Пол";
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.AutoScroll = true;
            this.splitContainer.Panel2.Controls.Add(genderIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.genderIDComboBox);
            this.splitContainer.Panel2.Controls.Add(mainHandIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.mainHandIDComboBox);
            this.splitContainer.Panel2.Controls.Add(phoneLabel);
            this.splitContainer.Panel2.Controls.Add(this.phoneMaskedTextBox);
            this.splitContainer.Panel2.Controls.Add(this.SaveAttentionBackground);
            this.splitContainer.Panel2.Controls.Add(dateLabel);
            this.splitContainer.Panel2.Controls.Add(this.dateDateTimePicker);
            this.splitContainer.Panel2.Controls.Add(fIOLabel);
            this.splitContainer.Panel2.Controls.Add(this.fIOTextBox);
            this.splitContainer.Panel2.Controls.Add(emailLabel);
            this.splitContainer.Panel2.Controls.Add(this.emailTextBox);
            this.splitContainer.Panel2.Controls.Add(cardLabel);
            this.splitContainer.Panel2.Controls.Add(this.cardTextBox);
            this.splitContainer.Panel2.Controls.Add(heightLabel);
            this.splitContainer.Panel2.Controls.Add(this.heightTextBox);
            this.splitContainer.Size = new System.Drawing.Size(375, 397);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 1;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(87, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(78, 13);
            this.titleLabelAttentionFont.TabIndex = 3;
            this.titleLabelAttentionFont.Text = "Новый ученик";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Willie_Starostin.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // genderIDComboBox
            // 
            this.genderIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.studentBindingSource, "GenderID", true));
            this.genderIDComboBox.DataSource = this.genderBindingSource;
            this.genderIDComboBox.DisplayMember = "Gender";
            this.genderIDComboBox.FormattingEnabled = true;
            this.genderIDComboBox.Location = new System.Drawing.Point(123, 218);
            this.genderIDComboBox.Name = "genderIDComboBox";
            this.genderIDComboBox.Size = new System.Drawing.Size(226, 21);
            this.genderIDComboBox.TabIndex = 20;
            this.genderIDComboBox.ValueMember = "IDGender";
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // willie_StarostinDataSet
            // 
            this.willie_StarostinDataSet.DataSetName = "Willie_StarostinDataSet";
            this.willie_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // genderBindingSource
            // 
            this.genderBindingSource.DataMember = "Gender";
            this.genderBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // mainHandIDComboBox
            // 
            this.mainHandIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.studentBindingSource, "MainHandID", true));
            this.mainHandIDComboBox.DataSource = this.handBindingSource;
            this.mainHandIDComboBox.DisplayMember = "MainHand";
            this.mainHandIDComboBox.FormattingEnabled = true;
            this.mainHandIDComboBox.Location = new System.Drawing.Point(123, 191);
            this.mainHandIDComboBox.Name = "mainHandIDComboBox";
            this.mainHandIDComboBox.Size = new System.Drawing.Size(226, 21);
            this.mainHandIDComboBox.TabIndex = 19;
            this.mainHandIDComboBox.ValueMember = "IDMainHand";
            // 
            // handBindingSource
            // 
            this.handBindingSource.DataMember = "Hand";
            this.handBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // phoneMaskedTextBox
            // 
            this.phoneMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.studentBindingSource, "Phone", true));
            this.phoneMaskedTextBox.Location = new System.Drawing.Point(123, 87);
            this.phoneMaskedTextBox.Mask = "+0 000 000 00 00";
            this.phoneMaskedTextBox.Name = "phoneMaskedTextBox";
            this.phoneMaskedTextBox.Size = new System.Drawing.Size(226, 20);
            this.phoneMaskedTextBox.TabIndex = 18;
            // 
            // SaveAttentionBackground
            // 
            this.SaveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SaveAttentionBackground.BackColor = System.Drawing.Color.Red;
            this.SaveAttentionBackground.Location = new System.Drawing.Point(20, 245);
            this.SaveAttentionBackground.Name = "SaveAttentionBackground";
            this.SaveAttentionBackground.Size = new System.Drawing.Size(329, 46);
            this.SaveAttentionBackground.TabIndex = 17;
            this.SaveAttentionBackground.Text = "Сохранить";
            this.SaveAttentionBackground.UseVisualStyleBackColor = false;
            this.SaveAttentionBackground.Click += new System.EventHandler(this.SaveAttentionBackground_Click);
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.studentBindingSource, "Date", true));
            this.dateDateTimePicker.Location = new System.Drawing.Point(123, 35);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(226, 20);
            this.dateDateTimePicker.TabIndex = 1;
            // 
            // fIOTextBox
            // 
            this.fIOTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.studentBindingSource, "FIO", true));
            this.fIOTextBox.Location = new System.Drawing.Point(123, 61);
            this.fIOTextBox.Name = "fIOTextBox";
            this.fIOTextBox.Size = new System.Drawing.Size(226, 20);
            this.fIOTextBox.TabIndex = 3;
            // 
            // emailTextBox
            // 
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.studentBindingSource, "Email", true));
            this.emailTextBox.Location = new System.Drawing.Point(123, 113);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(226, 20);
            this.emailTextBox.TabIndex = 7;
            // 
            // cardTextBox
            // 
            this.cardTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.studentBindingSource, "Card", true));
            this.cardTextBox.Location = new System.Drawing.Point(123, 139);
            this.cardTextBox.Name = "cardTextBox";
            this.cardTextBox.Size = new System.Drawing.Size(226, 20);
            this.cardTextBox.TabIndex = 9;
            // 
            // heightTextBox
            // 
            this.heightTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.studentBindingSource, "Height", true));
            this.heightTextBox.Location = new System.Drawing.Point(123, 165);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(226, 20);
            this.heightTextBox.TabIndex = 11;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EnemyTypeTableAdapter = null;
            this.tableAdapterManager.GenderTableAdapter = this.genderTableAdapter;
            this.tableAdapterManager.HandTableAdapter = this.handTableAdapter;
            this.tableAdapterManager.HistoryTrainingTableAdapter = null;
            this.tableAdapterManager.ProgramPunchTableAdapter = null;
            this.tableAdapterManager.ProgramTableAdapter = null;
            this.tableAdapterManager.PunchTableAdapter = null;
            this.tableAdapterManager.StudentTableAdapter = this.studentTableAdapter;
            this.tableAdapterManager.UpdateOrder = Willie_Starostin.Willie_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // genderTableAdapter
            // 
            this.genderTableAdapter.ClearBeforeFill = true;
            // 
            // handTableAdapter
            // 
            this.handTableAdapter.ClearBeforeFill = true;
            // 
            // CreateUpdateStudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 397);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateUpdateStudentForm";
            this.Text = "CreateUpdateStudentForm";
            this.Load += new System.EventHandler(this.CreateUpdateStudentForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.willie_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.genderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.handBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Willie_StarostinDataSet willie_StarostinDataSet;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private Willie_StarostinDataSetTableAdapters.StudentTableAdapter studentTableAdapter;
        private Willie_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button SaveAttentionBackground;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.TextBox fIOTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox cardTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.MaskedTextBox phoneMaskedTextBox;
        private System.Windows.Forms.ComboBox genderIDComboBox;
        private System.Windows.Forms.ComboBox mainHandIDComboBox;
        private Willie_StarostinDataSetTableAdapters.HandTableAdapter handTableAdapter;
        private System.Windows.Forms.BindingSource handBindingSource;
        private Willie_StarostinDataSetTableAdapters.GenderTableAdapter genderTableAdapter;
        private System.Windows.Forms.BindingSource genderBindingSource;
    }
}