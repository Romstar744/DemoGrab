﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Willie_Starostin.Models;
using Willie_Starostin.Services;

namespace Willie_Starostin.AppForms
{
    public partial class HistoryForm : Form
    {
        private Student _student;
        public HistoryForm(Student student)
        {
            InitializeComponent();
            _student = student;
            UserExperienceManager.SetTitle(this, $"История тренировок \"{_student.FIO}\"");
        }

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.Program". При необходимости она может быть перемещена или удалена.
            this.programTableAdapter.Fill(this.willie_StarostinDataSet.Program);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.HistoryTraining". При необходимости она может быть перемещена или удалена.
            //this.historyTrainingTableAdapter.Fill(this.willie_StarostinDataSet.HistoryTraining);

            historyTrainingBindingSource.DataSource = Program.context.HistoryTraining.Where(s => s.StudentID == _student.IDStudent).ToList();

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);

        }
    }
}
