﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Willie_Starostin.CustomControls;
using Willie_Starostin.Models;
using Willie_Starostin.Services;

namespace Willie_Starostin.AppForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            UserExperienceManager.SetTitle(this, "Список учеников");
        }

        private void ShowStudents()
        {
            List<Student> students = Program.context.Student.OrderBy(p => p.FIO).ToList();

            foreach (Student student in students)
            {
                flowLayoutPanel.Controls.Add(new StudentUserControl(student));
            }
        }

        private void ClearPartnerList()
        {
            splitContainer.Panel2.Controls[0].Controls.Clear();
        }

        public void RefreshPartners()
        {
            ClearPartnerList();
            ShowStudents();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ShowStudents();
            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
        }

        private void newStudentAttentionBackground_Click(object sender, EventArgs e)
        {
            CreateUpdateStudentForm createUpdateStudentForm = new CreateUpdateStudentForm();
            DialogResult studentSaved = createUpdateStudentForm.ShowDialog();

            if (studentSaved == DialogResult.OK)
            {
                RefreshPartners();
            }
        }

        private void newTrainingAttentionBackground_Click(object sender, EventArgs e)
        {
            CreateTrainingForm createTrainingForm = new CreateTrainingForm();
            DialogResult historySaved = createTrainingForm.ShowDialog();

            if (historySaved == DialogResult.OK)
            {
                RefreshPartners();
            }
        }
    }
}
