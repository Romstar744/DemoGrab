﻿namespace Willie_Starostin.AppForms
{
    partial class CreateTrainingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label studentIDLabel;
            System.Windows.Forms.Label typeEnemyIDLabel;
            System.Windows.Forms.Label programIDLabel;
            System.Windows.Forms.Label commentLabel;
            System.Windows.Forms.Label dateLabel;
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SaveAttentionBackground = new System.Windows.Forms.Button();
            this.studentIDComboBox = new System.Windows.Forms.ComboBox();
            this.historyTrainingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.willie_StarostinDataSet = new Willie_Starostin.Willie_StarostinDataSet();
            this.studentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeEnemyIDComboBox = new System.Windows.Forms.ComboBox();
            this.enemyTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.programIDComboBox = new System.Windows.Forms.ComboBox();
            this.programBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.commentTextBox = new System.Windows.Forms.TextBox();
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.historyTrainingTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.HistoryTrainingTableAdapter();
            this.tableAdapterManager = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.TableAdapterManager();
            this.enemyTypeTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.EnemyTypeTableAdapter();
            this.programTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.ProgramTableAdapter();
            this.studentTableAdapter = new Willie_Starostin.Willie_StarostinDataSetTableAdapters.StudentTableAdapter();
            studentIDLabel = new System.Windows.Forms.Label();
            typeEnemyIDLabel = new System.Windows.Forms.Label();
            programIDLabel = new System.Windows.Forms.Label();
            commentLabel = new System.Windows.Forms.Label();
            dateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyTrainingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.willie_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyTypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.programBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // studentIDLabel
            // 
            studentIDLabel.AutoSize = true;
            studentIDLabel.Location = new System.Drawing.Point(64, 17);
            studentIDLabel.Name = "studentIDLabel";
            studentIDLabel.Size = new System.Drawing.Size(44, 13);
            studentIDLabel.TabIndex = 0;
            studentIDLabel.Text = "Ученик";
            // 
            // typeEnemyIDLabel
            // 
            typeEnemyIDLabel.AutoSize = true;
            typeEnemyIDLabel.Location = new System.Drawing.Point(64, 44);
            typeEnemyIDLabel.Name = "typeEnemyIDLabel";
            typeEnemyIDLabel.Size = new System.Drawing.Size(88, 13);
            typeEnemyIDLabel.TabIndex = 2;
            typeEnemyIDLabel.Text = "Тип противника";
            // 
            // programIDLabel
            // 
            programIDLabel.AutoSize = true;
            programIDLabel.Location = new System.Drawing.Point(64, 71);
            programIDLabel.Name = "programIDLabel";
            programIDLabel.Size = new System.Drawing.Size(128, 13);
            programIDLabel.TabIndex = 4;
            programIDLabel.Text = "Программа тренировки";
            // 
            // commentLabel
            // 
            commentLabel.AutoSize = true;
            commentLabel.Location = new System.Drawing.Point(64, 98);
            commentLabel.Name = "commentLabel";
            commentLabel.Size = new System.Drawing.Size(77, 13);
            commentLabel.TabIndex = 6;
            commentLabel.Text = "Комментарий";
            // 
            // dateLabel
            // 
            dateLabel.AutoSize = true;
            dateLabel.Location = new System.Drawing.Point(64, 125);
            dateLabel.Name = "dateLabel";
            dateLabel.Size = new System.Drawing.Size(33, 13);
            dateLabel.TabIndex = 8;
            dateLabel.Text = "Дата";
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.AutoScroll = true;
            this.splitContainer.Panel2.Controls.Add(this.SaveAttentionBackground);
            this.splitContainer.Panel2.Controls.Add(studentIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.studentIDComboBox);
            this.splitContainer.Panel2.Controls.Add(typeEnemyIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.typeEnemyIDComboBox);
            this.splitContainer.Panel2.Controls.Add(programIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.programIDComboBox);
            this.splitContainer.Panel2.Controls.Add(commentLabel);
            this.splitContainer.Panel2.Controls.Add(this.commentTextBox);
            this.splitContainer.Panel2.Controls.Add(dateLabel);
            this.splitContainer.Panel2.Controls.Add(this.dateDateTimePicker);
            this.splitContainer.Size = new System.Drawing.Size(444, 306);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(87, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(101, 13);
            this.titleLabelAttentionFont.TabIndex = 3;
            this.titleLabelAttentionFont.Text = "Новая тренировка";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Willie_Starostin.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // SaveAttentionBackground
            // 
            this.SaveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SaveAttentionBackground.BackColor = System.Drawing.Color.Red;
            this.SaveAttentionBackground.Location = new System.Drawing.Point(67, 154);
            this.SaveAttentionBackground.Name = "SaveAttentionBackground";
            this.SaveAttentionBackground.Size = new System.Drawing.Size(330, 46);
            this.SaveAttentionBackground.TabIndex = 17;
            this.SaveAttentionBackground.Text = "Сохранить";
            this.SaveAttentionBackground.UseVisualStyleBackColor = false;
            this.SaveAttentionBackground.Click += new System.EventHandler(this.SaveAttentionBackground_Click);
            // 
            // studentIDComboBox
            // 
            this.studentIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.historyTrainingBindingSource, "StudentID", true));
            this.studentIDComboBox.DataSource = this.studentBindingSource;
            this.studentIDComboBox.DisplayMember = "FIO";
            this.studentIDComboBox.FormattingEnabled = true;
            this.studentIDComboBox.Location = new System.Drawing.Point(197, 14);
            this.studentIDComboBox.Name = "studentIDComboBox";
            this.studentIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.studentIDComboBox.TabIndex = 1;
            this.studentIDComboBox.ValueMember = "IDStudent";
            // 
            // historyTrainingBindingSource
            // 
            this.historyTrainingBindingSource.DataMember = "HistoryTraining";
            this.historyTrainingBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // willie_StarostinDataSet
            // 
            this.willie_StarostinDataSet.DataSetName = "Willie_StarostinDataSet";
            this.willie_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // studentBindingSource
            // 
            this.studentBindingSource.DataMember = "Student";
            this.studentBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // typeEnemyIDComboBox
            // 
            this.typeEnemyIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.historyTrainingBindingSource, "TypeEnemyID", true));
            this.typeEnemyIDComboBox.DataSource = this.enemyTypeBindingSource;
            this.typeEnemyIDComboBox.DisplayMember = "Enemy";
            this.typeEnemyIDComboBox.FormattingEnabled = true;
            this.typeEnemyIDComboBox.Location = new System.Drawing.Point(197, 41);
            this.typeEnemyIDComboBox.Name = "typeEnemyIDComboBox";
            this.typeEnemyIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.typeEnemyIDComboBox.TabIndex = 3;
            this.typeEnemyIDComboBox.ValueMember = "IDEnemy";
            // 
            // enemyTypeBindingSource
            // 
            this.enemyTypeBindingSource.DataMember = "EnemyType";
            this.enemyTypeBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // programIDComboBox
            // 
            this.programIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.historyTrainingBindingSource, "ProgramID", true));
            this.programIDComboBox.DataSource = this.programBindingSource;
            this.programIDComboBox.DisplayMember = "Program";
            this.programIDComboBox.FormattingEnabled = true;
            this.programIDComboBox.Location = new System.Drawing.Point(197, 68);
            this.programIDComboBox.Name = "programIDComboBox";
            this.programIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.programIDComboBox.TabIndex = 5;
            this.programIDComboBox.ValueMember = "IDProgram";
            // 
            // programBindingSource
            // 
            this.programBindingSource.DataMember = "Program";
            this.programBindingSource.DataSource = this.willie_StarostinDataSet;
            // 
            // commentTextBox
            // 
            this.commentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.historyTrainingBindingSource, "Comment", true));
            this.commentTextBox.Location = new System.Drawing.Point(197, 95);
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(200, 20);
            this.commentTextBox.TabIndex = 7;
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.historyTrainingBindingSource, "Date", true));
            this.dateDateTimePicker.Location = new System.Drawing.Point(197, 121);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateDateTimePicker.TabIndex = 9;
            // 
            // historyTrainingTableAdapter
            // 
            this.historyTrainingTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EnemyTypeTableAdapter = this.enemyTypeTableAdapter;
            this.tableAdapterManager.GenderTableAdapter = null;
            this.tableAdapterManager.HandTableAdapter = null;
            this.tableAdapterManager.HistoryTrainingTableAdapter = this.historyTrainingTableAdapter;
            this.tableAdapterManager.ProgramPunchTableAdapter = null;
            this.tableAdapterManager.ProgramTableAdapter = this.programTableAdapter;
            this.tableAdapterManager.PunchTableAdapter = null;
            this.tableAdapterManager.StudentTableAdapter = this.studentTableAdapter;
            this.tableAdapterManager.UpdateOrder = Willie_Starostin.Willie_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // enemyTypeTableAdapter
            // 
            this.enemyTypeTableAdapter.ClearBeforeFill = true;
            // 
            // programTableAdapter
            // 
            this.programTableAdapter.ClearBeforeFill = true;
            // 
            // studentTableAdapter
            // 
            this.studentTableAdapter.ClearBeforeFill = true;
            // 
            // CreateTrainingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 306);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateTrainingForm";
            this.Text = "CreateTrainingForm";
            this.Load += new System.EventHandler(this.CreateTrainingForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyTrainingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.willie_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyTypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.programBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private Willie_StarostinDataSet willie_StarostinDataSet;
        private System.Windows.Forms.BindingSource historyTrainingBindingSource;
        private Willie_StarostinDataSetTableAdapters.HistoryTrainingTableAdapter historyTrainingTableAdapter;
        private Willie_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button SaveAttentionBackground;
        private System.Windows.Forms.ComboBox studentIDComboBox;
        private System.Windows.Forms.ComboBox typeEnemyIDComboBox;
        private System.Windows.Forms.ComboBox programIDComboBox;
        private System.Windows.Forms.TextBox commentTextBox;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Willie_StarostinDataSetTableAdapters.StudentTableAdapter studentTableAdapter;
        private System.Windows.Forms.BindingSource studentBindingSource;
        private Willie_StarostinDataSetTableAdapters.EnemyTypeTableAdapter enemyTypeTableAdapter;
        private System.Windows.Forms.BindingSource enemyTypeBindingSource;
        private Willie_StarostinDataSetTableAdapters.ProgramTableAdapter programTableAdapter;
        private System.Windows.Forms.BindingSource programBindingSource;
    }
}