﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Willie_Starostin.Exceptions;
using Willie_Starostin.Models;
using Willie_Starostin.Services;

namespace Willie_Starostin.AppForms
{
    public partial class CreateUpdateStudentForm : Form
    {
        Student _student;
        public CreateUpdateStudentForm()
        {
            InitializeComponent();
            _student = new Student();
            UserExperienceManager.SetTitle(this, "Новый ученик");
        }

        public CreateUpdateStudentForm(Student partner)
        {
            InitializeComponent();
            _student = partner;
            UserExperienceManager.SetTitle(this, $"Изменить ученика: \"{_student.FIO}\"");
        }

        private void CreateUpdateStudentForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.Gender". При необходимости она может быть перемещена или удалена.
            this.genderTableAdapter.Fill(this.willie_StarostinDataSet.Gender);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.Hand". При необходимости она может быть перемещена или удалена.
            this.handTableAdapter.Fill(this.willie_StarostinDataSet.Hand);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.Student". При необходимости она может быть перемещена или удалена.
            //this.studentTableAdapter.Fill(this.willie_StarostinDataSet.Student);

            if (!_student.isNew())
            {
                studentBindingSource.DataSource = _student;
            }

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
            UserExperienceManager.CustomizeControls(splitContainer.Panel2.Controls);
        }

        private string GetSanitizedPhone()
        {
            // PKGH            
            // Подготовка введенной пользователем информации
            // о телефоне для сохранения в БД.

            string trimmedPhone = phoneMaskedTextBox.Text.Replace("+", "");
            trimmedPhone = trimmedPhone.Replace(" ", "");
            return trimmedPhone;
        }

        private void FillModelFields()
        {
            _student.Date = dateDateTimePicker.Value;
            _student.FIO = fIOTextBox.Text;
            _student.Phone = GetSanitizedPhone();
            _student.Email = emailTextBox.Text;
            _student.Card = cardTextBox.Text;
            _student.Height = int.Parse(heightTextBox.Text);
            _student.MainHandID = (int)mainHandIDComboBox.SelectedValue;
            _student.GenderID = (int)genderIDComboBox.SelectedValue;
        }

        private void ValidateGeneral(string userInputText, string field, string messageAboutAllowedSymbols = "поле не должно быть пустым.", string pattern = @"^.+$")
        {
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
            bool isValid = regex.IsMatch(userInputText.Trim());
            if (!isValid)
            {
                throw new ValidationException($"{field}: {messageAboutAllowedSymbols}");
            }
        }


        private void ValidatePartnerName()
        {
            ValidateGeneral(fIOTextBox.Text, "Полное имя");
        }

        private void ValidatePhone()
        {
            ValidateGeneral(GetSanitizedPhone(), "Телефон", "должно быть 11 цифр.", @"^\d{11}$");
        }

        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Normalize the domain
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                    RegexOptions.None, TimeSpan.FromMilliseconds(200));

                // Examines the domain part of the email and normalizes it.
                string DomainMapper(Match match)
                {
                    // Use IdnMapping class to convert Unicode domain names.
                    var idn = new IdnMapping();

                    // Pull out and process domain name (throws ArgumentException on invalid)
                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        private void ValidateEmail()
        {
            if (!IsValidEmail(emailTextBox.Text.Trim()))
            {
                throw new ValidationException("Неверный формат электронной почты");
            }
        }

        private void ValidateCodeNumber()
        {
            ValidateGeneral(cardTextBox.Text, "Номер карты", "Не верный формат поля.", @"^(V?X{0,3}(IV|IX|V?I{0,3})|I{1,3})-[A-Z]{2}-\d{3}(?:-\d{2}){2,3}$");
        }

        private void ValidateHeight()
        {
            ValidateGeneral(heightTextBox.Text, "Рост", "Рост не может быть отречательным или запредельно большим", @"^(?:[1-9]?[0-9]|[1-2][0-9]{2}|300)$");
        }

        private void Validate()
        {
            ValidatePartnerName();
            ValidatePhone();
            ValidateEmail();
            ValidateHeight();
            ValidateCodeNumber();
        }

        private void SaveAttentionBackground_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            FillModelFields();

            if (_student.isNew())
            {
                Program.context.Student.Add(_student);
            }


            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
