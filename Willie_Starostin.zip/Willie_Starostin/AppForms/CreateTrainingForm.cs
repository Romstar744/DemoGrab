﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Willie_Starostin.Exceptions;
using Willie_Starostin.Models;
using Willie_Starostin.Services;

namespace Willie_Starostin.AppForms
{
    public partial class CreateTrainingForm : Form
    {
        HistoryTraining _history;

        public CreateTrainingForm()
        {
            InitializeComponent();
            _history = new HistoryTraining();
            UserExperienceManager.SetTitle(this, "Новая тренировка");
        }

        private void CreateTrainingForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.Program". При необходимости она может быть перемещена или удалена.
            this.programTableAdapter.Fill(this.willie_StarostinDataSet.Program);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.EnemyType". При необходимости она может быть перемещена или удалена.
            this.enemyTypeTableAdapter.Fill(this.willie_StarostinDataSet.EnemyType);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.Student". При необходимости она может быть перемещена или удалена.
            this.studentTableAdapter.Fill(this.willie_StarostinDataSet.Student);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "willie_StarostinDataSet.HistoryTraining". При необходимости она может быть перемещена или удалена.
            this.historyTrainingTableAdapter.Fill(this.willie_StarostinDataSet.HistoryTraining);
        }

        private void FillModelFields()
        {
            _history.StudentID = (int)studentIDComboBox.SelectedValue;
            _history.TypeEnemyID = (int)typeEnemyIDComboBox.SelectedValue;
            _history.ProgramID = (int)programIDComboBox.SelectedValue;
            _history.Comment = commentTextBox.Text;
            _history.Date = dateDateTimePicker.Value;
        }

        private void ValidateGeneral(string userInputText, string field, string messageAboutAllowedSymbols = "поле не должно быть пустым.", string pattern = @"^.+$")
        {
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
            bool isValid = regex.IsMatch(userInputText.Trim());
            if (!isValid)
            {
                throw new ValidationException($"{field}: {messageAboutAllowedSymbols}");
            }
        }

        private void ValidateComment()
        {
            ValidateGeneral(commentTextBox.Text, "Комментарий");
        }

        private void ValidateHeight()
        {

            var studentId = (int)studentIDComboBox.SelectedValue;
            var opponentId = (int)typeEnemyIDComboBox.SelectedValue;
            var programId = (int)programIDComboBox.SelectedValue;

            var student = GetEntityById<Student>(studentId);
            var studentPredominantHand = student.Hand.MainHand.ToLower();
            var opponent = GetEntityById<EnemyType>(opponentId);
            var program = GetEntityById<Models.Program>(programId);

            var heightCategoryStudent = DetermineHeightCategory(student.Height, student.Gender.Gender1);
            var heightCategoryOpponent = GetOpponentHeightCategory(opponent.Enemy);
            var programHeightsAndPredominantHand = ExtractProgramHeightsAndPredominantHand(program.Program1.ToLowerInvariant());

            if (programHeightsAndPredominantHand[0] == "рост" && programHeightsAndPredominantHand.Count == 3
                && (heightCategoryStudent != programHeightsAndPredominantHand[1] || heightCategoryOpponent[0] != programHeightsAndPredominantHand[2]))
            {
                throw new ValidationException($"Рост ученика или соперника не соответствует параметрам тренировки:{program.Program1}.");
            }
            else if (programHeightsAndPredominantHand[0] == "рука" && programHeightsAndPredominantHand.Count == 3
                && (studentPredominantHand != programHeightsAndPredominantHand[1] || heightCategoryOpponent[1] != programHeightsAndPredominantHand[2]))
            {
                throw new ValidationException($"Рука ученика или соперника не соответствует параметрам тренировки:{program.Program1}.");
            }

            if (programHeightsAndPredominantHand.Count == 5
                && (heightCategoryStudent != programHeightsAndPredominantHand[1] || studentPredominantHand != programHeightsAndPredominantHand[2]))
            {
                throw new ValidationException($"Рост и рука ученика не соответствуют параметрам тренировки:{program.Program1}.");
            }


            if (programHeightsAndPredominantHand.Count == 5
                && (heightCategoryOpponent[0] != programHeightsAndPredominantHand[3] || heightCategoryOpponent[1] != programHeightsAndPredominantHand[4]))
            {
                throw new ValidationException($"Рост и рука соперника не соответствуют параметрам тренировки:{program.Program1}.");
            }
        }

        private T GetEntityById<T>(int id) where T : class
        {
            return Program.context.Set<T>().Find(id);
        }

        private string DetermineHeightCategory(double? height, string gender)
        {
            if (gender == "муж")
            {
                if (height >= 185) return "высокий";
                if (height >= 175) return "средний";
                return "низкий";
            }
            else if (gender == "жен")
            {
                if (height >= 170) return "высокий";
                if (height >= 160) return "средний";
                return "низкий";
            }
            return string.Empty;
        }
        private string[] GetOpponentHeightCategory(string opponentHeight)
        {
            var opponentDetails = opponentHeight.ToLower().Split(' ');
            if (opponentDetails[0] == "среднего")
            {
                opponentDetails[0] = "средний";
            }
            return opponentDetails;
        }

        private List<string> ExtractProgramHeightsAndPredominantHand(string programName)
        {
            Dictionary<int, string> heightsAndPredominantHand = new Dictionary<int, string>();

            List<string> heightsAndPredominantHandList = new List<string> { "высок", "средн", "низк", "прав", "лев" };

            foreach (string line in heightsAndPredominantHandList)
            {
                int index = 0;
                while ((index = programName.IndexOf(line, index)) != -1)
                {
                    string value = line;
                    if (line == "прав" || line == "лев")
                    {
                        value += "ша";
                        heightsAndPredominantHand[-1] = "рука";
                    }
                    else
                    {
                        value += "ий";
                        if (value == "средний")
                        {
                            heightsAndPredominantHand[index + 1] = value;
                        }
                        heightsAndPredominantHand[-1] = "рост";
                    }

                    heightsAndPredominantHand[index] = value;
                    index += line.Length;
                }
            }


            return heightsAndPredominantHand.OrderBy(h => h.Key).Select(h => h.Value).ToList();
        }

        private void Validate()
        {
            ValidateComment();
            ValidateHeight();
        }

        private void SaveAttentionBackground_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Program.context.HistoryTraining.Add(_history);

            FillModelFields();

            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
