﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Willie_Starostin.Constants
{
    internal class Color
    {
        public const string mainBackgroundColor = "#FFFFFF";
        public const string auxColor = "#F4E8D3";
        public const string attentionColor = "#FF0000";
    }
}
