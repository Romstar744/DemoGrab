namespace Willie_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ProgramPunch")]
    public partial class ProgramPunch
    {
        [Key]
        public int IDPrgoramPucnhes { get; set; }

        public int? IdProgram { get; set; }

        public int? IdPunches { get; set; }

        public virtual Program Program { get; set; }

        public virtual Punch Punch { get; set; }
    }
}
