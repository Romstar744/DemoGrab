namespace Willie_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;

    [Table("Student")]
    public partial class Student
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Student()
        {
            HistoryTraining = new HashSet<HistoryTraining>();
        }

        [Key]
        public int IDStudent { get; set; }

        public DateTime? Date { get; set; }

        [StringLength(255)]
        public string FIO { get; set; }

        public string Phone { get; set; }

        [StringLength(255)]
        public string Email { get; set; }

        [StringLength(255)]
        public string Card { get; set; }

        public int? Height { get; set; }

        public int? MainHandID { get; set; }

        public int? GenderID { get; set; }

        public virtual Gender Gender { get; set; }

        public virtual Hand Hand { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HistoryTraining> HistoryTraining { get; set; }

        public int GetAmountDate()
        {
            var sum = 0;
            return sum += Willie_Starostin.Program.context.HistoryTraining.Where(x => x.StudentID == IDStudent).Select(x => x.Date).Distinct().Count();
        }
        public bool isNew()
        {
            return IDStudent == 0;
        }

        public int WilliCount
        {
            get
            {
                return GetAmountDate();
            }
        }
    }
}
