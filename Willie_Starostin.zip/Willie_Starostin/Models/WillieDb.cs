using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Willie_Starostin.Models
{
    public partial class WillieDb : DbContext
    {
        public WillieDb()
            : base("name=WillieDb")
        {
        }

        public virtual DbSet<EnemyType> EnemyType { get; set; }
        public virtual DbSet<Gender> Gender { get; set; }
        public virtual DbSet<Hand> Hand { get; set; }
        public virtual DbSet<HistoryTraining> HistoryTraining { get; set; }
        public virtual DbSet<Program> Program { get; set; }
        public virtual DbSet<ProgramPunch> ProgramPunch { get; set; }
        public virtual DbSet<Punch> Punch { get; set; }
        public virtual DbSet<Student> Student { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EnemyType>()
                .HasMany(e => e.HistoryTraining)
                .WithOptional(e => e.EnemyType)
                .HasForeignKey(e => e.TypeEnemyID);

            modelBuilder.Entity<Gender>()
                .HasMany(e => e.Student)
                .WithOptional(e => e.Gender)
                .HasForeignKey(e => e.GenderID);

            modelBuilder.Entity<Hand>()
                .HasMany(e => e.Student)
                .WithOptional(e => e.Hand)
                .HasForeignKey(e => e.MainHandID);

            modelBuilder.Entity<Program>()
                .HasMany(e => e.HistoryTraining)
                .WithOptional(e => e.Program)
                .HasForeignKey(e => e.ProgramID);

            modelBuilder.Entity<Student>()
                .HasMany(e => e.HistoryTraining)
                .WithOptional(e => e.Student)
                .HasForeignKey(e => e.StudentID);
        }
    }
}
