namespace Willie_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("EnemyType")]
    public partial class EnemyType
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public EnemyType()
        {
            HistoryTraining = new HashSet<HistoryTraining>();
        }

        [Key]
        public int IDEnemy { get; set; }

        [Required]
        [StringLength(255)]
        public string Enemy { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HistoryTraining> HistoryTraining { get; set; }
    }
}
