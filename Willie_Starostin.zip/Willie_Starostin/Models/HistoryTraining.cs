namespace Willie_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HistoryTraining")]
    public partial class HistoryTraining
    {
        [Key]
        public int IDHistory { get; set; }

        public int? StudentID { get; set; }

        public int? TypeEnemyID { get; set; }

        public int? ProgramID { get; set; }

        [StringLength(255)]
        public string Comment { get; set; }

        public DateTime? Date { get; set; }

        public virtual EnemyType EnemyType { get; set; }

        public virtual Program Program { get; set; }

        public virtual Student Student { get; set; }
    }
}
