﻿namespace Willie_Starostin.CustomControls
{
    partial class StudentUserControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.historyAttentionBackground = new System.Windows.Forms.Button();
            this.WillieCount = new System.Windows.Forms.Label();
            this.СardStudent = new System.Windows.Forms.Label();
            this.Fio = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // historyAttentionBackground
            // 
            this.historyAttentionBackground.BackColor = System.Drawing.Color.Red;
            this.historyAttentionBackground.Location = new System.Drawing.Point(655, 34);
            this.historyAttentionBackground.Name = "historyAttentionBackground";
            this.historyAttentionBackground.Size = new System.Drawing.Size(75, 23);
            this.historyAttentionBackground.TabIndex = 7;
            this.historyAttentionBackground.Text = "История";
            this.historyAttentionBackground.UseVisualStyleBackColor = false;
            this.historyAttentionBackground.Click += new System.EventHandler(this.historyAttentionBackground_Click);
            // 
            // WillieCount
            // 
            this.WillieCount.Location = new System.Drawing.Point(650, 12);
            this.WillieCount.Name = "WillieCount";
            this.WillieCount.Size = new System.Drawing.Size(80, 13);
            this.WillieCount.TabIndex = 6;
            this.WillieCount.Text = "Вилли:";
            this.WillieCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.WillieCount.Click += new System.EventHandler(this.StudentUserControl_Click);
            // 
            // СardStudent
            // 
            this.СardStudent.AutoSize = true;
            this.СardStudent.Location = new System.Drawing.Point(9, 34);
            this.СardStudent.Name = "СardStudent";
            this.СardStudent.Size = new System.Drawing.Size(80, 13);
            this.СardStudent.TabIndex = 5;
            this.СardStudent.Text = "Карта ученика";
            this.СardStudent.Click += new System.EventHandler(this.StudentUserControl_Click);
            // 
            // Fio
            // 
            this.Fio.AutoSize = true;
            this.Fio.Location = new System.Drawing.Point(9, 12);
            this.Fio.Name = "Fio";
            this.Fio.Size = new System.Drawing.Size(30, 13);
            this.Fio.TabIndex = 4;
            this.Fio.Text = "Фио";
            this.Fio.Click += new System.EventHandler(this.StudentUserControl_Click);
            // 
            // StudentUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(232)))), ((int)(((byte)(211)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.historyAttentionBackground);
            this.Controls.Add(this.WillieCount);
            this.Controls.Add(this.СardStudent);
            this.Controls.Add(this.Fio);
            this.Name = "StudentUserControl";
            this.Size = new System.Drawing.Size(736, 67);
            this.Load += new System.EventHandler(this.StudentUserControl_Load);
            this.Click += new System.EventHandler(this.StudentUserControl_Click);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.StudentUserControl_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button historyAttentionBackground;
        private System.Windows.Forms.Label WillieCount;
        private System.Windows.Forms.Label СardStudent;
        private System.Windows.Forms.Label Fio;
    }
}
