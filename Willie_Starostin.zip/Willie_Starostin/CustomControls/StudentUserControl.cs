﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Willie_Starostin.AppForms;
using Willie_Starostin.Models;
using Willie_Starostin.Services;

namespace Willie_Starostin.CustomControls
{
    public partial class StudentUserControl : UserControl
    {
        private Student _student;
        public StudentUserControl(Student student)
        {
            InitializeComponent();
            _student = student;
            SetLabeTextlValues();
        }

        private void SetLabeTextlValues()
        {
            Fio.Text = _student.FIO;
            СardStudent.Text = $"Карта ученика: {_student.Card}";
            WillieCount.Text = $"Вилли: {_student.WilliCount} дней";
        }

        private void historyAttentionBackground_Click(object sender, EventArgs e)
        {
            HistoryForm historyForm = new HistoryForm(_student);
            historyForm.ShowDialog();
        }

        private void StudentUserControl_Click(object sender, EventArgs e)
        {
            CreateUpdateStudentForm createUpdatePartnerForm = new CreateUpdateStudentForm(_student);
            DialogResult studentSaved = createUpdatePartnerForm.ShowDialog();

            if (studentSaved == DialogResult.OK)
            {
                MainForm mainForm = (MainForm)this.Parent.Parent.Parent.Parent;
                mainForm.RefreshPartners();
            }
        }

        private void StudentUserControl_Load(object sender, EventArgs e)
        {
            UserExperienceManager.CustomizeControls(this.Controls);
        }

        private void StudentUserControl_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, ClientRectangle,
                ColorTranslator.FromHtml(Constants.Color.attentionColor), ButtonBorderStyle.Solid);
        }
    }
}
