﻿using DoctorDok_Starostin.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorDok_Starostin.Services
{
        public static class CourierInstructionGenerator
        {
        /// <summary>
        /// PKGH
        /// Метод для подготовки поручения курьеру.
        /// </summary>
        /// <param name="letter">Объект письма.</param>
        /// <returns>Текст поручения курьеру.</returns>
        public static string GenerateInstruction(Letters letter)
        {
            string direction = letter.Type.Type1 == "Исх" ? "Доставить" : "Забрать";
            string correspondentLabel = letter.Type.Type1 == "Исх" ? "Получатель" : "Отправитель";
            string addressLine = !string.IsNullOrEmpty(letter.Address) ? $"Адрес: {letter.Address}" : "";
            string registrationLine = letter.Type.Type1 == "Исх" ? $"№ {letter.Type.ShortName}-{letter.Department.ShortName}-{letter.Case.Case1}/{letter.ID}" : "";
            string grifLine = letter.Grif != null ? $"{letter.Grif.Grif1}\n" : "";
            string dateLine = letter.DateRegistration.HasValue ? letter.DateRegistration.Value.ToString("dd.MM.yyyy", CultureInfo.InvariantCulture) + "\n" : "";


            return $"{grifLine}" +
                   $"{dateLine}" +
                   $"Поручение\n" +
                   $"[{direction}] корреспонденцию.\n" +
                   $"{correspondentLabel}: {letter.Correspondent.Сorrespondent}\n" +
                   $"{addressLine}\n" +
                   $"{registrationLine}\n";
        }
    }
    }
