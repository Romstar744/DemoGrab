﻿namespace DoctorDok_Starostin.AppForms
{
    partial class HistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.doctordok_StarostinDataSet = new DoctorDok_Starostin.Doctordok_StarostinDataSet();
            this.lettersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lettersTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.LettersTableAdapter();
            this.tableAdapterManager = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.TableAdapterManager();
            this.lettersDataGridView = new System.Windows.Forms.DataGridView();
            this.caseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.caseTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.CaseTableAdapter();
            this.typeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.TypeTableAdapter();
            this.correspondentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.correspondentTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.CorrespondentTableAdapter();
            this.communicationMethodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.communicationMethodTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.CommunicationMethodTableAdapter();
            this.grifBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grifTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.GrifTableAdapter();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctordok_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettersDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.caseBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.correspondentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.communicationMethodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grifBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.AutoScroll = true;
            this.splitContainer.Panel2.Controls.Add(this.lettersDataGridView);
            this.splitContainer.Panel2.Padding = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.splitContainer.Size = new System.Drawing.Size(800, 450);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 1;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(85, 20);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(178, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "ИСТОРИЯ КОРРЕСПОНДЕНЦИИ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DoctorDok_Starostin.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // doctordok_StarostinDataSet
            // 
            this.doctordok_StarostinDataSet.DataSetName = "Doctordok_StarostinDataSet";
            this.doctordok_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lettersBindingSource
            // 
            this.lettersBindingSource.DataMember = "Letters";
            this.lettersBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // lettersTableAdapter
            // 
            this.lettersTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CaseTableAdapter = this.caseTableAdapter;
            this.tableAdapterManager.CommunicationMethodTableAdapter = this.communicationMethodTableAdapter;
            this.tableAdapterManager.CorrespondentTableAdapter = this.correspondentTableAdapter;
            this.tableAdapterManager.DepartmentTableAdapter = null;
            this.tableAdapterManager.GrifTableAdapter = this.grifTableAdapter;
            this.tableAdapterManager.LettersTableAdapter = this.lettersTableAdapter;
            this.tableAdapterManager.TypeTableAdapter = this.typeTableAdapter;
            this.tableAdapterManager.UpdateOrder = DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lettersDataGridView
            // 
            this.lettersDataGridView.AllowUserToAddRows = false;
            this.lettersDataGridView.AllowUserToDeleteRows = false;
            this.lettersDataGridView.AutoGenerateColumns = false;
            this.lettersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.lettersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lettersDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn10});
            this.lettersDataGridView.DataSource = this.lettersBindingSource;
            this.lettersDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lettersDataGridView.Location = new System.Drawing.Point(20, 0);
            this.lettersDataGridView.Name = "lettersDataGridView";
            this.lettersDataGridView.ReadOnly = true;
            this.lettersDataGridView.Size = new System.Drawing.Size(760, 336);
            this.lettersDataGridView.TabIndex = 0;
            // 
            // caseBindingSource
            // 
            this.caseBindingSource.DataMember = "Case";
            this.caseBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // caseTableAdapter
            // 
            this.caseTableAdapter.ClearBeforeFill = true;
            // 
            // typeBindingSource
            // 
            this.typeBindingSource.DataMember = "Type";
            this.typeBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // typeTableAdapter
            // 
            this.typeTableAdapter.ClearBeforeFill = true;
            // 
            // correspondentBindingSource
            // 
            this.correspondentBindingSource.DataMember = "Correspondent";
            this.correspondentBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // correspondentTableAdapter
            // 
            this.correspondentTableAdapter.ClearBeforeFill = true;
            // 
            // communicationMethodBindingSource
            // 
            this.communicationMethodBindingSource.DataMember = "CommunicationMethod";
            this.communicationMethodBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // communicationMethodTableAdapter
            // 
            this.communicationMethodTableAdapter.ClearBeforeFill = true;
            // 
            // grifBindingSource
            // 
            this.grifBindingSource.DataMember = "Grif";
            this.grifBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // grifTableAdapter
            // 
            this.grifTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DateRegistration";
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата регистрации";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CaseID";
            this.dataGridViewTextBoxColumn6.DataSource = this.caseBindingSource;
            this.dataGridViewTextBoxColumn6.DisplayMember = "Case";
            this.dataGridViewTextBoxColumn6.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn6.HeaderText = "Номер дела";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.ValueMember = "ID";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "TypeID";
            this.dataGridViewTextBoxColumn3.DataSource = this.typeBindingSource;
            this.dataGridViewTextBoxColumn3.DisplayMember = "Type";
            this.dataGridViewTextBoxColumn3.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn3.HeaderText = "Тип";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.ValueMember = "ID";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "СorrespondentID";
            this.dataGridViewTextBoxColumn7.DataSource = this.correspondentBindingSource;
            this.dataGridViewTextBoxColumn7.DisplayMember = "Сorrespondent";
            this.dataGridViewTextBoxColumn7.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn7.HeaderText = "Адресат";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn7.ValueMember = "ID";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "CommunicationMethodID";
            this.dataGridViewTextBoxColumn4.DataSource = this.communicationMethodBindingSource;
            this.dataGridViewTextBoxColumn4.DisplayMember = "CommunicationMethod";
            this.dataGridViewTextBoxColumn4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn4.HeaderText = "Тип связи";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.ValueMember = "ID";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "GrifID";
            this.dataGridViewTextBoxColumn10.DataSource = this.grifBindingSource;
            this.dataGridViewTextBoxColumn10.DisplayMember = "Grif";
            this.dataGridViewTextBoxColumn10.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn10.HeaderText = "Гриф";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn10.ValueMember = "ID";
            // 
            // HistoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer);
            this.Name = "HistoryForm";
            this.Text = "HistoryForm";
            this.Load += new System.EventHandler(this.HistoryForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctordok_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettersDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.caseBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.correspondentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.communicationMethodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grifBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Doctordok_StarostinDataSet doctordok_StarostinDataSet;
        private System.Windows.Forms.BindingSource lettersBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.LettersTableAdapter lettersTableAdapter;
        private Doctordok_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView lettersDataGridView;
        private Doctordok_StarostinDataSetTableAdapters.CaseTableAdapter caseTableAdapter;
        private System.Windows.Forms.BindingSource caseBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.TypeTableAdapter typeTableAdapter;
        private System.Windows.Forms.BindingSource typeBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.CorrespondentTableAdapter correspondentTableAdapter;
        private System.Windows.Forms.BindingSource correspondentBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.CommunicationMethodTableAdapter communicationMethodTableAdapter;
        private System.Windows.Forms.BindingSource communicationMethodBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.GrifTableAdapter grifTableAdapter;
        private System.Windows.Forms.BindingSource grifBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn10;
    }
}