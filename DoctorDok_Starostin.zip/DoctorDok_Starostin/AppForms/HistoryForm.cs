﻿using DoctorDok_Starostin.Models;
using DoctorDok_Starostin.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoctorDok_Starostin.AppForms
{
    public partial class HistoryForm : ParentForm
    {
        private Letters _letter;
        public HistoryForm(Letters letter)
        {
            InitializeComponent();
            _letter = letter;
            UserExperienceManager.SetTitle(this, $"Корреспонденция \"{_letter.СorrespondentID}\"");
        }

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Grif". При необходимости она может быть перемещена или удалена.
            this.grifTableAdapter.Fill(this.doctordok_StarostinDataSet.Grif);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.CommunicationMethod". При необходимости она может быть перемещена или удалена.
            this.communicationMethodTableAdapter.Fill(this.doctordok_StarostinDataSet.CommunicationMethod);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Correspondent". При необходимости она может быть перемещена или удалена.
            this.correspondentTableAdapter.Fill(this.doctordok_StarostinDataSet.Correspondent);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Type". При необходимости она может быть перемещена или удалена.
            this.typeTableAdapter.Fill(this.doctordok_StarostinDataSet.Type);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Case". При необходимости она может быть перемещена или удалена.
            this.caseTableAdapter.Fill(this.doctordok_StarostinDataSet.Case);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Letters". При необходимости она может быть перемещена или удалена.
            this.lettersTableAdapter.Fill(this.doctordok_StarostinDataSet.Letters);

            lettersBindingSource.DataSource = Program.context.Letters.
                Where(p => p.ID == _letter.ID).OrderByDescending(p => p.DateRegistration).ToList();

        }
    }
}
