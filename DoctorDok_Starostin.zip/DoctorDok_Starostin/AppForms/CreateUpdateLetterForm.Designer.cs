﻿namespace DoctorDok_Starostin.AppForms
{
    partial class CreateUpdateLetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dateRegistrationLabel;
            System.Windows.Forms.Label typeIDLabel;
            System.Windows.Forms.Label communicationMethodIDLabel;
            System.Windows.Forms.Label departmentIDLabel;
            System.Windows.Forms.Label сorrespondentIDLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label descriptionLabel;
            System.Windows.Forms.Label grifIDLabel;
            System.Windows.Forms.Label caseIDLabel;
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.doctordok_StarostinDataSet = new DoctorDok_Starostin.Doctordok_StarostinDataSet();
            this.lettersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lettersTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.LettersTableAdapter();
            this.tableAdapterManager = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.TableAdapterManager();
            this.dateRegistrationDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.typeIDComboBox = new System.Windows.Forms.ComboBox();
            this.communicationMethodIDComboBox = new System.Windows.Forms.ComboBox();
            this.departmentIDComboBox = new System.Windows.Forms.ComboBox();
            this.сorrespondentIDComboBox = new System.Windows.Forms.ComboBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.grifIDComboBox = new System.Windows.Forms.ComboBox();
            this.saveAttentionBackground = new System.Windows.Forms.Button();
            this.typeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.TypeTableAdapter();
            this.communicationMethodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.communicationMethodTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.CommunicationMethodTableAdapter();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.DepartmentTableAdapter();
            this.correspondentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.correspondentTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.CorrespondentTableAdapter();
            this.grifBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.grifTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.GrifTableAdapter();
            this.caseIDComboBox = new System.Windows.Forms.ComboBox();
            this.caseBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.caseTableAdapter = new DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.CaseTableAdapter();
            dateRegistrationLabel = new System.Windows.Forms.Label();
            typeIDLabel = new System.Windows.Forms.Label();
            communicationMethodIDLabel = new System.Windows.Forms.Label();
            departmentIDLabel = new System.Windows.Forms.Label();
            сorrespondentIDLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            grifIDLabel = new System.Windows.Forms.Label();
            caseIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctordok_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.communicationMethodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.correspondentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grifBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.caseBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.AutoScroll = true;
            this.splitContainer.Panel2.Controls.Add(caseIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.caseIDComboBox);
            this.splitContainer.Panel2.Controls.Add(this.saveAttentionBackground);
            this.splitContainer.Panel2.Controls.Add(dateRegistrationLabel);
            this.splitContainer.Panel2.Controls.Add(this.dateRegistrationDateTimePicker);
            this.splitContainer.Panel2.Controls.Add(typeIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.typeIDComboBox);
            this.splitContainer.Panel2.Controls.Add(communicationMethodIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.communicationMethodIDComboBox);
            this.splitContainer.Panel2.Controls.Add(departmentIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.departmentIDComboBox);
            this.splitContainer.Panel2.Controls.Add(сorrespondentIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.сorrespondentIDComboBox);
            this.splitContainer.Panel2.Controls.Add(addressLabel);
            this.splitContainer.Panel2.Controls.Add(this.addressTextBox);
            this.splitContainer.Panel2.Controls.Add(descriptionLabel);
            this.splitContainer.Panel2.Controls.Add(this.descriptionTextBox);
            this.splitContainer.Panel2.Controls.Add(grifIDLabel);
            this.splitContainer.Panel2.Controls.Add(this.grifIDComboBox);
            this.splitContainer.Panel2.Padding = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.splitContainer.Size = new System.Drawing.Size(411, 513);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(85, 20);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(136, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "РЕГИСТРАЦИЯ ПИСЬМА";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::DoctorDok_Starostin.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // doctordok_StarostinDataSet
            // 
            this.doctordok_StarostinDataSet.DataSetName = "Doctordok_StarostinDataSet";
            this.doctordok_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lettersBindingSource
            // 
            this.lettersBindingSource.DataMember = "Letters";
            this.lettersBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // lettersTableAdapter
            // 
            this.lettersTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CaseTableAdapter = this.caseTableAdapter;
            this.tableAdapterManager.CommunicationMethodTableAdapter = this.communicationMethodTableAdapter;
            this.tableAdapterManager.CorrespondentTableAdapter = this.correspondentTableAdapter;
            this.tableAdapterManager.DepartmentTableAdapter = this.departmentTableAdapter;
            this.tableAdapterManager.GrifTableAdapter = this.grifTableAdapter;
            this.tableAdapterManager.LettersTableAdapter = this.lettersTableAdapter;
            this.tableAdapterManager.TypeTableAdapter = this.typeTableAdapter;
            this.tableAdapterManager.UpdateOrder = DoctorDok_Starostin.Doctordok_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dateRegistrationLabel
            // 
            dateRegistrationLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            dateRegistrationLabel.AutoSize = true;
            dateRegistrationLabel.Location = new System.Drawing.Point(18, 68);
            dateRegistrationLabel.Name = "dateRegistrationLabel";
            dateRegistrationLabel.Size = new System.Drawing.Size(92, 13);
            dateRegistrationLabel.TabIndex = 0;
            dateRegistrationLabel.Text = "Date Registration:";
            // 
            // dateRegistrationDateTimePicker
            // 
            this.dateRegistrationDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateRegistrationDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.lettersBindingSource, "DateRegistration", true));
            this.dateRegistrationDateTimePicker.Enabled = false;
            this.dateRegistrationDateTimePicker.Location = new System.Drawing.Point(159, 64);
            this.dateRegistrationDateTimePicker.Name = "dateRegistrationDateTimePicker";
            this.dateRegistrationDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateRegistrationDateTimePicker.TabIndex = 1;
            // 
            // typeIDLabel
            // 
            typeIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            typeIDLabel.AutoSize = true;
            typeIDLabel.Location = new System.Drawing.Point(18, 93);
            typeIDLabel.Name = "typeIDLabel";
            typeIDLabel.Size = new System.Drawing.Size(48, 13);
            typeIDLabel.TabIndex = 2;
            typeIDLabel.Text = "Type ID:";
            // 
            // typeIDComboBox
            // 
            this.typeIDComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.typeIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.lettersBindingSource, "TypeID", true));
            this.typeIDComboBox.DataSource = this.typeBindingSource;
            this.typeIDComboBox.DisplayMember = "Type";
            this.typeIDComboBox.FormattingEnabled = true;
            this.typeIDComboBox.Location = new System.Drawing.Point(159, 90);
            this.typeIDComboBox.Name = "typeIDComboBox";
            this.typeIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.typeIDComboBox.TabIndex = 3;
            this.typeIDComboBox.ValueMember = "ID";
            // 
            // communicationMethodIDLabel
            // 
            communicationMethodIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            communicationMethodIDLabel.AutoSize = true;
            communicationMethodIDLabel.Location = new System.Drawing.Point(18, 120);
            communicationMethodIDLabel.Name = "communicationMethodIDLabel";
            communicationMethodIDLabel.Size = new System.Drawing.Size(135, 13);
            communicationMethodIDLabel.TabIndex = 4;
            communicationMethodIDLabel.Text = "Communication Method ID:";
            // 
            // communicationMethodIDComboBox
            // 
            this.communicationMethodIDComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.communicationMethodIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.lettersBindingSource, "CommunicationMethodID", true));
            this.communicationMethodIDComboBox.DataSource = this.communicationMethodBindingSource;
            this.communicationMethodIDComboBox.DisplayMember = "CommunicationMethod";
            this.communicationMethodIDComboBox.FormattingEnabled = true;
            this.communicationMethodIDComboBox.Location = new System.Drawing.Point(159, 117);
            this.communicationMethodIDComboBox.Name = "communicationMethodIDComboBox";
            this.communicationMethodIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.communicationMethodIDComboBox.TabIndex = 5;
            this.communicationMethodIDComboBox.ValueMember = "ID";
            // 
            // departmentIDLabel
            // 
            departmentIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            departmentIDLabel.AutoSize = true;
            departmentIDLabel.Location = new System.Drawing.Point(18, 147);
            departmentIDLabel.Name = "departmentIDLabel";
            departmentIDLabel.Size = new System.Drawing.Size(79, 13);
            departmentIDLabel.TabIndex = 6;
            departmentIDLabel.Text = "Department ID:";
            // 
            // departmentIDComboBox
            // 
            this.departmentIDComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.departmentIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.lettersBindingSource, "DepartmentID", true));
            this.departmentIDComboBox.DataSource = this.departmentBindingSource;
            this.departmentIDComboBox.DisplayMember = "Department";
            this.departmentIDComboBox.FormattingEnabled = true;
            this.departmentIDComboBox.Location = new System.Drawing.Point(159, 144);
            this.departmentIDComboBox.Name = "departmentIDComboBox";
            this.departmentIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.departmentIDComboBox.TabIndex = 7;
            this.departmentIDComboBox.ValueMember = "ID";
            // 
            // сorrespondentIDLabel
            // 
            сorrespondentIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            сorrespondentIDLabel.AutoSize = true;
            сorrespondentIDLabel.Location = new System.Drawing.Point(18, 202);
            сorrespondentIDLabel.Name = "сorrespondentIDLabel";
            сorrespondentIDLabel.Size = new System.Drawing.Size(93, 13);
            сorrespondentIDLabel.TabIndex = 8;
            сorrespondentIDLabel.Text = "Сorrespondent ID:";
            // 
            // сorrespondentIDComboBox
            // 
            this.сorrespondentIDComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.сorrespondentIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.lettersBindingSource, "СorrespondentID", true));
            this.сorrespondentIDComboBox.DataSource = this.correspondentBindingSource;
            this.сorrespondentIDComboBox.DisplayMember = "Сorrespondent";
            this.сorrespondentIDComboBox.FormattingEnabled = true;
            this.сorrespondentIDComboBox.Location = new System.Drawing.Point(159, 199);
            this.сorrespondentIDComboBox.Name = "сorrespondentIDComboBox";
            this.сorrespondentIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.сorrespondentIDComboBox.TabIndex = 9;
            this.сorrespondentIDComboBox.ValueMember = "ID";
            // 
            // addressLabel
            // 
            addressLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(18, 230);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(48, 13);
            addressLabel.TabIndex = 10;
            addressLabel.Text = "Address:";
            // 
            // addressTextBox
            // 
            this.addressTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addressTextBox.Location = new System.Drawing.Point(159, 227);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(200, 20);
            this.addressTextBox.TabIndex = 11;
            // 
            // descriptionLabel
            // 
            descriptionLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            descriptionLabel.AutoSize = true;
            descriptionLabel.Location = new System.Drawing.Point(18, 256);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(63, 13);
            descriptionLabel.TabIndex = 12;
            descriptionLabel.Text = "Description:";
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.descriptionTextBox.Location = new System.Drawing.Point(159, 253);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(200, 20);
            this.descriptionTextBox.TabIndex = 13;
            // 
            // grifIDLabel
            // 
            grifIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            grifIDLabel.AutoSize = true;
            grifIDLabel.Location = new System.Drawing.Point(18, 282);
            grifIDLabel.Name = "grifIDLabel";
            grifIDLabel.Size = new System.Drawing.Size(40, 13);
            grifIDLabel.TabIndex = 14;
            grifIDLabel.Text = "Grif ID:";
            // 
            // grifIDComboBox
            // 
            this.grifIDComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grifIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.lettersBindingSource, "GrifID", true));
            this.grifIDComboBox.DataSource = this.grifBindingSource;
            this.grifIDComboBox.DisplayMember = "Grif";
            this.grifIDComboBox.FormattingEnabled = true;
            this.grifIDComboBox.Location = new System.Drawing.Point(159, 279);
            this.grifIDComboBox.Name = "grifIDComboBox";
            this.grifIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.grifIDComboBox.TabIndex = 15;
            this.grifIDComboBox.ValueMember = "ID";
            // 
            // saveAttentionBackground
            // 
            this.saveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.saveAttentionBackground.Location = new System.Drawing.Point(79, 307);
            this.saveAttentionBackground.Name = "saveAttentionBackground";
            this.saveAttentionBackground.Size = new System.Drawing.Size(280, 57);
            this.saveAttentionBackground.TabIndex = 16;
            this.saveAttentionBackground.Text = "Сохранить";
            this.saveAttentionBackground.UseVisualStyleBackColor = true;
            this.saveAttentionBackground.Click += new System.EventHandler(this.saveAttentionBackground_Click);
            // 
            // typeBindingSource
            // 
            this.typeBindingSource.DataMember = "Type";
            this.typeBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // typeTableAdapter
            // 
            this.typeTableAdapter.ClearBeforeFill = true;
            // 
            // communicationMethodBindingSource
            // 
            this.communicationMethodBindingSource.DataMember = "CommunicationMethod";
            this.communicationMethodBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // communicationMethodTableAdapter
            // 
            this.communicationMethodTableAdapter.ClearBeforeFill = true;
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // correspondentBindingSource
            // 
            this.correspondentBindingSource.DataMember = "Correspondent";
            this.correspondentBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // correspondentTableAdapter
            // 
            this.correspondentTableAdapter.ClearBeforeFill = true;
            // 
            // grifBindingSource
            // 
            this.grifBindingSource.DataMember = "Grif";
            this.grifBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // grifTableAdapter
            // 
            this.grifTableAdapter.ClearBeforeFill = true;
            // 
            // caseIDLabel
            // 
            caseIDLabel.AutoSize = true;
            caseIDLabel.Location = new System.Drawing.Point(18, 174);
            caseIDLabel.Name = "caseIDLabel";
            caseIDLabel.Size = new System.Drawing.Size(48, 13);
            caseIDLabel.TabIndex = 17;
            caseIDLabel.Text = "Case ID:";
            // 
            // caseIDComboBox
            // 
            this.caseIDComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.lettersBindingSource, "CaseID", true));
            this.caseIDComboBox.DataSource = this.caseBindingSource;
            this.caseIDComboBox.DisplayMember = "Case";
            this.caseIDComboBox.FormattingEnabled = true;
            this.caseIDComboBox.Location = new System.Drawing.Point(159, 171);
            this.caseIDComboBox.Name = "caseIDComboBox";
            this.caseIDComboBox.Size = new System.Drawing.Size(200, 21);
            this.caseIDComboBox.TabIndex = 18;
            this.caseIDComboBox.ValueMember = "ID";
            // 
            // caseBindingSource
            // 
            this.caseBindingSource.DataMember = "Case";
            this.caseBindingSource.DataSource = this.doctordok_StarostinDataSet;
            // 
            // caseTableAdapter
            // 
            this.caseTableAdapter.ClearBeforeFill = true;
            // 
            // CreateUpdateLetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 513);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateUpdateLetterForm";
            this.Text = "CreateUpdatePartnerForm";
            this.Load += new System.EventHandler(this.CreateUpdateLetterForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.doctordok_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lettersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.communicationMethodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.correspondentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grifBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.caseBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Doctordok_StarostinDataSet doctordok_StarostinDataSet;
        private System.Windows.Forms.BindingSource lettersBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.LettersTableAdapter lettersTableAdapter;
        private Doctordok_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button saveAttentionBackground;
        private System.Windows.Forms.DateTimePicker dateRegistrationDateTimePicker;
        private System.Windows.Forms.ComboBox typeIDComboBox;
        private System.Windows.Forms.ComboBox communicationMethodIDComboBox;
        private System.Windows.Forms.ComboBox departmentIDComboBox;
        private System.Windows.Forms.ComboBox сorrespondentIDComboBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.ComboBox grifIDComboBox;
        private Doctordok_StarostinDataSetTableAdapters.TypeTableAdapter typeTableAdapter;
        private System.Windows.Forms.BindingSource typeBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.CommunicationMethodTableAdapter communicationMethodTableAdapter;
        private System.Windows.Forms.BindingSource communicationMethodBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.CorrespondentTableAdapter correspondentTableAdapter;
        private System.Windows.Forms.BindingSource correspondentBindingSource;
        private Doctordok_StarostinDataSetTableAdapters.GrifTableAdapter grifTableAdapter;
        private System.Windows.Forms.BindingSource grifBindingSource;
        private System.Windows.Forms.ComboBox caseIDComboBox;
        private Doctordok_StarostinDataSetTableAdapters.CaseTableAdapter caseTableAdapter;
        private System.Windows.Forms.BindingSource caseBindingSource;
    }
}