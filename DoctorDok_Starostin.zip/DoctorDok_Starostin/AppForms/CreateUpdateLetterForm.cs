﻿using DoctorDok_Starostin.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoctorDok_Starostin.AppForms
{
    public partial class CreateUpdateLetterForm : Form
    {
        Letters _letter;
        public CreateUpdateLetterForm()
        {
            InitializeComponent();
            _letter = new Letters();
            Program.context.Letters.Add(_letter);

        }

        private void CreateUpdateLetterForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Case". При необходимости она может быть перемещена или удалена.
            this.caseTableAdapter.Fill(this.doctordok_StarostinDataSet.Case);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Grif". При необходимости она может быть перемещена или удалена.
            this.grifTableAdapter.Fill(this.doctordok_StarostinDataSet.Grif);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Correspondent". При необходимости она может быть перемещена или удалена.
            this.correspondentTableAdapter.Fill(this.doctordok_StarostinDataSet.Correspondent);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Department". При необходимости она может быть перемещена или удалена.
            this.departmentTableAdapter.Fill(this.doctordok_StarostinDataSet.Department);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.CommunicationMethod". При необходимости она может быть перемещена или удалена.
            this.communicationMethodTableAdapter.Fill(this.doctordok_StarostinDataSet.CommunicationMethod);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Type". При необходимости она может быть перемещена или удалена.
            this.typeTableAdapter.Fill(this.doctordok_StarostinDataSet.Type);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Letters". При необходимости она может быть перемещена или удалена.
            //this.lettersTableAdapter.Fill(this.doctordok_StarostinDataSet.Letters);

        }

        private void FillModelFields()
        {
            //_letter.PartnerName = partnerNameTextBox.Text.Trim();
            //_letter.PartnerTypeId = (int)this.partnerTypeIdComboBox.SelectedValue;
            //_partner.Rating = int.Parse(this.ratingTextBox.Text);
            //_partner.Address = this.addressTextBox.Text.Trim();
            //_partner.Ceo = this.ceoTextBox.Text.Trim();
            //_partner.Phone = Int64.Parse(this.phoneMaskedTextBox.Text);
            //_partner.Email = this.emailTextBox.Text.Trim();

            _letter.DateRegistration = dateRegistrationDateTimePicker.Value.Date;
            _letter.TypeID = (int)this.typeIDComboBox.SelectedValue;
            _letter.CommunicationMethodID = (int)this.communicationMethodIDComboBox.SelectedValue;
            _letter.DepartmentID = (int)this.departmentIDComboBox.SelectedValue;
            _letter.СorrespondentID = (int)this.сorrespondentIDComboBox.SelectedValue;
            _letter.Address = this.addressTextBox.Text.Trim();
            _letter.Description = this.descriptionTextBox.Text.Trim();
            _letter.GrifID = (int)this.grifIDComboBox.SelectedValue;
            _letter.CaseID = (int)this.caseIDComboBox.SelectedValue;

        }


        private void saveAttentionBackground_Click(object sender, EventArgs e)
        {
            FillModelFields();

            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
    }
}
