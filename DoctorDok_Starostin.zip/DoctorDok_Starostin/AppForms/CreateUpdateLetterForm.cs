﻿using DoctorDok_Starostin.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DoctorDok_Starostin.Exceptions;
using System.Text.RegularExpressions;
using DoctorDok_Starostin.Services;

namespace DoctorDok_Starostin.AppForms
{
    public partial class CreateUpdateLetterForm : ParentForm
    {
        Letters _letter;
        public CreateUpdateLetterForm()
        {
            InitializeComponent();
            _letter = new Letters();
            //Program.context.Letters.Add(_letter);
            UserExperienceManager.SetTitle(this, "Новое письмо");
        }

        public CreateUpdateLetterForm(Letters letter)
        {
            InitializeComponent();
            _letter = letter;
            UserExperienceManager.SetTitle(this, $"Изменить письмо от адресата: \"{_letter.Correspondent.Сorrespondent}\"");
        }


        private void CreateUpdateLetterForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Case". При необходимости она может быть перемещена или удалена.
            this.caseTableAdapter.Fill(this.doctordok_StarostinDataSet.Case);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Grif". При необходимости она может быть перемещена или удалена.
            this.grifTableAdapter.Fill(this.doctordok_StarostinDataSet.Grif);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Correspondent". При необходимости она может быть перемещена или удалена.
            this.correspondentTableAdapter.Fill(this.doctordok_StarostinDataSet.Correspondent);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Department". При необходимости она может быть перемещена или удалена.
            this.departmentTableAdapter.Fill(this.doctordok_StarostinDataSet.Department);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.CommunicationMethod". При необходимости она может быть перемещена или удалена.
            this.communicationMethodTableAdapter.Fill(this.doctordok_StarostinDataSet.CommunicationMethod);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Type". При необходимости она может быть перемещена или удалена.
            this.typeTableAdapter.Fill(this.doctordok_StarostinDataSet.Type);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "doctordok_StarostinDataSet.Letters". При необходимости она может быть перемещена или удалена.
            //this.lettersTableAdapter.Fill(this.doctordok_StarostinDataSet.Letters);


            if (!_letter.isNew())
            {
                lettersBindingSource.DataSource = _letter;
            }
            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
            UserExperienceManager.CustomizeControls(splitContainer.Panel2.Controls);



        }

        private void FillModelFields()
        {
            _letter.DateRegistration = dateRegistrationDateTimePicker.Value.Date;
            _letter.TypeID = (int)this.typeIDComboBox.SelectedValue;
            _letter.CommunicationMethodID = (int)this.communicationMethodIDComboBox.SelectedValue;
            _letter.DepartmentID = (int)this.departmentIDComboBox.SelectedValue;
            _letter.СorrespondentID = (int)this.сorrespondentIDComboBox.SelectedValue;
            _letter.Address = this.addressTextBox.Text.Trim();
            _letter.Description = this.descriptionTextBox.Text.Trim();
            _letter.GrifID = (int)this.grifIDComboBox.SelectedValue;
            _letter.CaseID = (int)this.caseIDComboBox.SelectedValue;
        }

        // <summary>
        /// PKGH
        /// Проверка введенной пользователем информации. Если допущена ошибка,
        /// сообщить, в каком поле это случилось, и что можно вводить.
        /// </summary>
        /// <param name="pattern">Паттерн</param>
        /// <param name="userInputText">Текст, введенный пользователем в поле на форме.</param>
        /// <param name="field">Поле, в котором пользователь допустил ошибку.</param>
        /// <param name="messageAboutAllowedSymbols">Какие символы разрешено вводить в это поле.</param>
        /// <exception cref="ValidationException"></exception>
        private void ValidateGeneral(string userInputText, string field, string messageAboutAllowedSymbols = "поле не должно быть пустым.", string pattern = @"^.+$")
        {
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
            bool isValid = regex.IsMatch(userInputText.Trim());
            if (!isValid)
            {
                throw new ValidationException($"{field}: {messageAboutAllowedSymbols}");
            }
        }

        private void ValidateAddress()
        {
            ValidateGeneral(addressTextBox.Text, "Адрес");
        }

        private void ValidateDescription()
        {
            ValidateGeneral(descriptionTextBox.Text, "Описание");
        }


        private void Validate()
        {
            ValidateAddress();
            ValidateDescription();
        }



        private void saveAttentionBackground_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FillModelFields();

            if (_letter.isNew())
            {
                Program.context.Letters.Add(_letter);
            }


            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
    }
}
