﻿using DoctorDok_Starostin.Models;
using DoctorDok_Starostin.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Reflection;

namespace DoctorDok_Starostin_UnitTest2
{
    [TestClass]
    public class CourierInstructionGeneratorTests
    {
        [TestMethod]
        public void TestGenerateOutgoingInstruction()
        {
            var letter = new Letters()
            {
                ID = 123,
                DateRegistration = new DateTime(2024, 10, 26),
                Address = "ул. Примерная, д. 1",
                Type = new DoctorDok_Starostin.Models.Type() { Type1 = "Исх", ShortName = "И" },
                Department = new Department() { ShortName = "ОТД" },
                Case = new Case() { Case1 = 1 },
                Correspondent = new Correspondent() { Сorrespondent = "ООО Рога и копыта" },
                Grif = new Grif() { Grif1 = "Конфиденциально" }
            };


            string instruction = CourierInstructionGenerator.GenerateInstruction(letter);

            string expectedInstruction = "Конфиденциально\n" +
                                         "26.10.2024\n" +
                                         "Поручение\n" +
                                         "[Доставить] корреспонденцию.\n" +
                                         "Получатель: ООО Рога и копыта\n" +
                                         "Адрес: ул. Примерная, д. 1\n" +
                                         "№ И-ОТД-1/123\n";
            Assert.AreEqual(expectedInstruction, instruction);

        }

        [TestMethod]
        public void TestGenerateIncomingInstruction()
        {
            var letter = new Letters()
            {
                ID = 123,
                DateRegistration = new DateTime(2024, 10, 26),
                Address = "ул. Примерная, д. 1",
                Type = new DoctorDok_Starostin.Models.Type() { Type1 = "Вх", ShortName = "В" },
                Department = new Department() { ShortName = "ОТД" },
                Case = new Case() { Case1 = 1 },
                Correspondent = new Correspondent() { Сorrespondent = "ООО Ромашка" },
            };

            string instruction = CourierInstructionGenerator.GenerateInstruction(letter);

            string expectedInstruction =
                "26.10.2024\n" +
                "Поручение\n" +
                "[Забрать] корреспонденцию.\n" +
                "Отправитель: ООО Ромашка\n" +
                "Адрес: ул. Примерная, д. 1\n" +
                "\n";

            Assert.AreEqual(expectedInstruction, instruction);
        }
        [TestMethod]
        public void TestGenerateInstructionWithoutGrif()
        {
            var letter = new Letters()
            {
                ID = 123,
                DateRegistration = new DateTime(2024, 10, 26),
                Address = "ул. Примерная, д. 1",
                Type = new DoctorDok_Starostin.Models.Type() { Type1 = "Исх", ShortName = "И" },
                Department = new Department() { ShortName = "ОТД" },
                Case = new Case() { Case1 = 1 },
                Correspondent = new Correspondent() { Сorrespondent = "ООО Рога и копыта" }
            };

            string instruction = CourierInstructionGenerator.GenerateInstruction(letter);

            string expectedInstruction =
                "26.10.2024\n" +
                "Поручение\n" +
                "[Доставить] корреспонденцию.\n" +
                "Получатель: ООО Рога и копыта\n" +
                "Адрес: ул. Примерная, д. 1\n" +
                 "№ И-ОТД-1/123\n";


            Assert.AreEqual(expectedInstruction, instruction);
        }
        [TestMethod]
        public void TestGenerateInstructionWithoutDate()
        {
            var letter = new Letters()
            {
                ID = 123,
                Address = "ул. Примерная, д. 1",
                Type = new DoctorDok_Starostin.Models.Type() { Type1 = "Исх", ShortName = "И" },
                Department = new Department() { ShortName = "ОТД" },
                Case = new Case() { Case1 = 1 },
                Correspondent = new Correspondent() { Сorrespondent = "ООО Рога и копыта" }
            };
            string instruction = CourierInstructionGenerator.GenerateInstruction(letter);

            string expectedInstruction =
                "Поручение\n" +
                "[Доставить] корреспонденцию.\n" +
                "Получатель: ООО Рога и копыта\n" +
                "Адрес: ул. Примерная, д. 1\n" +
                "№ И-ОТД-1/123\n";

            Assert.AreEqual(expectedInstruction, instruction);
        }
        [TestMethod]
        public void TestGenerateInstructionWithoutAddress()
        {
            var letter = new Letters()
            {
                ID = 123,
                DateRegistration = new DateTime(2024, 10, 26),
                Type = new DoctorDok_Starostin.Models.Type() { Type1 = "Исх", ShortName = "И" },
                Department = new Department() { ShortName = "ОТД" },
                Case = new Case() { Case1 = 1 },
                Correspondent = new Correspondent() { Сorrespondent = "ООО Рога и копыта" }
            };
            string instruction = CourierInstructionGenerator.GenerateInstruction(letter);

            string expectedInstruction =
               "26.10.2024\n" +
               "Поручение\n" +
               "[Доставить] корреспонденцию.\n" +
               "Получатель: ООО Рога и копыта\n" +
               "\n" +
               "№ И-ОТД-1/123\n";

            Assert.AreEqual(expectedInstruction, instruction);
        }

        [TestMethod]
        public void TestGenerateIncomingInstructionWithoutAddress()
        {
            var letter = new Letters()
            {
                ID = 123,
                DateRegistration = new DateTime(2024, 10, 26),
                Type = new DoctorDok_Starostin.Models.Type() { Type1 = "Вх", ShortName = "В" },
                Department = new Department() { ShortName = "ОТД" },
                Case = new Case() { Case1 = 1 },
                Correspondent = new Correspondent() { Сorrespondent = "ООО Ромашка" },
            };

            string instruction = CourierInstructionGenerator.GenerateInstruction(letter);

            string expectedInstruction =
                "26.10.2024\n" +
                "Поручение\n" +
                "[Забрать] корреспонденцию.\n" +
                "Отправитель: ООО Ромашка\n" +
               "\n";

            Assert.AreEqual(expectedInstruction, instruction);
        }
    }
}
