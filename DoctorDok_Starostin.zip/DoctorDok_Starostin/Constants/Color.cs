﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorDok_Starostin.Constants
{
    /// <summary>
    /// PKGH
    /// 
    /// Цвета.
    /// </summary>

    internal class Color
    {
        public const string incoming = "#008080";
        public const string outgoing = "#FF00FF";
        public const string attentionColor = "#FF0000";
        public const string mainBackgroundColor = "#FFFFFF";
        public const string auxColor = "#F4E8D3";
    }
}
