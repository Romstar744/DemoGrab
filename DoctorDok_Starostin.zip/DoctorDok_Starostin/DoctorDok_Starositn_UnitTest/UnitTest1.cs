﻿using DoctorDok_Starostin.CustomControls;
using DoctorDok_Starostin.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace DoctorDok_Starositn_UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// PKGH
        /// Проверка метода CalculateMaterialAmount.
        /// </summary>
        public static DoctorDokPb context = new DoctorDokPb();
        [TestMethod]
        public void TestMethod1()
        { 
            var letters = context.Letters.FirstOrDefault(p => p.ID == 1);
            Assert.AreEqual(letters.GetAmountProblems(), 1);
        }
    }
}
