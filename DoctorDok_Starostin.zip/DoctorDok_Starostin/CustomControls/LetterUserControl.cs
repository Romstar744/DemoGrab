﻿using DoctorDok_Starostin.AppForms;
using DoctorDok_Starostin.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoctorDok_Starostin.CustomControls
{
    public partial class LetterUserControl : UserControl
    {
        private Letters _letter;
        public LetterUserControl(Letters letters)
        {
            InitializeComponent();
            _letter = letters;
            SetLabeTextlValues();
        }

        private void SetLabeTextlValues()
        {
            Adresat.Text = $"Адресат: {_letter.Correspondent.Сorrespondent}";
            Date.Text = $"Дата: {_letter.DateRegistration?.ToString("dd.MM.yyyy") ?? ""}";
            Number.Text = $"Номер: {_letter.Type.ShortName}-{_letter.Department.ShortName}-{_letter.Case.Case1}/{_letter.ID}";
            CountProblemLetter.Text = $"{_letter.Count}";
        }

        private void historyAttentionBackground_Click(object sender, EventArgs e)
        {
            HistoryForm historyForm = new HistoryForm(_letter);
            historyForm.ShowDialog();
        }
    }
}
