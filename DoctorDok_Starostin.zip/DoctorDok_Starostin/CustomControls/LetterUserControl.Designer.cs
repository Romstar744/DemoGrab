﻿namespace DoctorDok_Starostin.CustomControls
{
    partial class LetterUserControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Adresat = new System.Windows.Forms.Label();
            this.Date = new System.Windows.Forms.Label();
            this.Number = new System.Windows.Forms.Label();
            this.CountProblemLetter = new System.Windows.Forms.Label();
            this.historyAttentionBackground = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Adresat
            // 
            this.Adresat.AutoSize = true;
            this.Adresat.Location = new System.Drawing.Point(23, 20);
            this.Adresat.Name = "Adresat";
            this.Adresat.Size = new System.Drawing.Size(52, 13);
            this.Adresat.TabIndex = 0;
            this.Adresat.Text = "Адресат:";
            // 
            // Date
            // 
            this.Date.AutoSize = true;
            this.Date.Location = new System.Drawing.Point(23, 69);
            this.Date.Name = "Date";
            this.Date.Size = new System.Drawing.Size(36, 13);
            this.Date.TabIndex = 1;
            this.Date.Text = "Дата:";
            // 
            // Number
            // 
            this.Number.AutoSize = true;
            this.Number.Location = new System.Drawing.Point(23, 115);
            this.Number.Name = "Number";
            this.Number.Size = new System.Drawing.Size(44, 13);
            this.Number.TabIndex = 2;
            this.Number.Text = "Номер:";
            // 
            // CountProblemLetter
            // 
            this.CountProblemLetter.AutoSize = true;
            this.CountProblemLetter.Location = new System.Drawing.Point(598, 20);
            this.CountProblemLetter.Name = "CountProblemLetter";
            this.CountProblemLetter.Size = new System.Drawing.Size(127, 13);
            this.CountProblemLetter.TabIndex = 3;
            this.CountProblemLetter.Text = "По проблеме: ? письма";
            this.CountProblemLetter.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // historyAttentionBackground
            // 
            this.historyAttentionBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(186)))), ((int)(((byte)(128)))));
            this.historyAttentionBackground.Location = new System.Drawing.Point(650, 102);
            this.historyAttentionBackground.Name = "historyAttentionBackground";
            this.historyAttentionBackground.Size = new System.Drawing.Size(75, 23);
            this.historyAttentionBackground.TabIndex = 4;
            this.historyAttentionBackground.Text = "История";
            this.historyAttentionBackground.UseVisualStyleBackColor = false;
            // 
            // LetterUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(232)))), ((int)(((byte)(211)))));
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.historyAttentionBackground);
            this.Controls.Add(this.CountProblemLetter);
            this.Controls.Add(this.Number);
            this.Controls.Add(this.Date);
            this.Controls.Add(this.Adresat);
            this.Margin = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.Name = "LetterUserControl";
            this.Padding = new System.Windows.Forms.Padding(20);
            this.Size = new System.Drawing.Size(738, 148);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Adresat;
        private System.Windows.Forms.Label Date;
        private System.Windows.Forms.Label Number;
        private System.Windows.Forms.Label CountProblemLetter;
        private System.Windows.Forms.Button historyAttentionBackground;
    }
}
