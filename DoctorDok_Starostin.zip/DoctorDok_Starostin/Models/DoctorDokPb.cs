﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace DoctorDok_Starostin.Models
{
    public partial class DoctorDokPb : DbContext
    {
        public DoctorDokPb()
            : base("name=DoctorDokPb")
        {
        }

        public virtual DbSet<Case> Case { get; set; }
        public virtual DbSet<CommunicationMethod> CommunicationMethod { get; set; }
        public virtual DbSet<Correspondent> Correspondent { get; set; }
        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Grif> Grif { get; set; }
        public virtual DbSet<Letters> Letters { get; set; }
        public virtual DbSet<Type> Type { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Correspondent>()
                .HasMany(e => e.Letters)
                .WithOptional(e => e.Correspondent)
                .HasForeignKey(e => e.СorrespondentID);
        }
    }
}
