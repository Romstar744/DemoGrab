namespace DoctorDok_Starostin.Models
{
    using DoctorDok_Starostin.CustomControls;
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Migrations.History;
    using System.Data.Entity.Spatial;
    using System.Linq;

    public partial class Letters
    {
        [Key]
        public int ID { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? DateRegistration { get; set; }

        public int? TypeID { get; set; }

        public int? CommunicationMethodID { get; set; }

        public int? DepartmentID { get; set; }

        public int? CaseID { get; set; }

        public int? СorrespondentID { get; set; }

        [StringLength(255)]
        public string Address { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        public int? GrifID { get; set; }

        public virtual Case Case { get; set; }

        public virtual Correspondent Correspondent { get; set; }

        public virtual Department Department { get; set; }

        public virtual Grif Grif { get; set; }

        public virtual Type Type { get; set; }
        
        public int GetAmountProblems()
        {
            var sum = 0;
            return sum += Program.context.Letters.Where(p => p.ID == ID).OrderByDescending(p => p.DateRegistration).Count();
        }

        public bool isNew()
        {
            return ID == 0;
        }

        public int Count
        {
            get
            {
                return GetAmountProblems();
            }
        }
    }
}
