namespace DoctorDok_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Letters
    {
        [Key]
        public int ID { get; set; }

        [Column(TypeName = "smalldatetime")]
        public DateTime? DateRegistration { get; set; }

        public int? TypeID { get; set; }

        public int? CommunicationMethodID { get; set; }

        public int? DepartmentID { get; set; }

        public int? CaseID { get; set; }

        public int? СorrespondentID { get; set; }

        [StringLength(255)]
        public string Address { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        public int? GrifID { get; set; }

        public virtual Case Case { get; set; }

        public virtual Correspondent Correspondent { get; set; }

        public virtual Department Department { get; set; }

        public virtual Grif Grif { get; set; }

        public virtual Type Type { get; set; }

        public int Count
        {
            get
            {
                return 1;
            }
        }

    }
}
