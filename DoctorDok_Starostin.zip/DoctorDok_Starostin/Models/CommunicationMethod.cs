namespace DoctorDok_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("CommunicationMethod")]
    public partial class CommunicationMethod
    {
        [Key]
        public int ID { get; set; }

        [Column("CommunicationMethod")]
        [StringLength(255)]
        public string CommunicationMethod1 { get; set; }
    }
}
