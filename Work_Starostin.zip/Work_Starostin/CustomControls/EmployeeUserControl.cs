﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Work_Starostin.AppForms;
using Work_Starostin.Models;
using Work_Starostin.Services;

namespace Work_Starostin.CustomControls
{
    public partial class EmployeeUserControl : UserControl
    {
        private Employee _employee;
        public EmployeeUserControl(Employee employee)
        {
            InitializeComponent();
            _employee = employee;
            SetLabelTextValues();
        }

        private void SetLabelTextValues()
        {
            surname.Text = $"Фамилия: {_employee.Surname}";
            name.Text = $"Имя: {_employee.Name}";
            middleName.Text = $"Отчество: {_employee.MiddleName}";
            phone.Text = $"Телефон: {String.Format("{0: +0 000 000 00 00}", _employee.Phone)}";
            email.Text = $"Электронная почта: {_employee.Email}";
            harmCount.Text = $"Вредность: {_employee.HarmCount}";
            if (_employee.HarmCount > 3)
            {
                this.BackColor = Color.Red;
            }
        }

        private void historyAttentionBackground_Click(object sender, EventArgs e)
        {
            HistoryForm historyWork = new HistoryForm(_employee);
            historyWork.ShowDialog();
        }

        private void EmployeeUserControl_Load(object sender, EventArgs e)
        {
            UserExperienceManager.CustomizeControls(this.Controls);
        }

        private void EmployeeUserControl_Click(object sender, EventArgs e)
        {
            CreateUpdateEmployeeForm createUpdateEmployee = new CreateUpdateEmployeeForm(_employee);
            DialogResult employeeSaved = createUpdateEmployee.ShowDialog();

            if (employeeSaved == DialogResult.OK)
            {
                MainForm mainForm = (MainForm)this.Parent.Parent.Parent.Parent;
                mainForm.RefreshEmployee();
            }
        }

        private void EmployeeUserControl_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, ClientRectangle,
               ColorTranslator.FromHtml(Constants.Color.attentionColor), ButtonBorderStyle.Solid);
        }
    }
}
