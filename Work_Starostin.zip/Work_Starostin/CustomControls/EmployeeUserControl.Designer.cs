﻿namespace Work_Starostin.CustomControls
{
    partial class EmployeeUserControl
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.historyAttentionBackground = new System.Windows.Forms.Button();
            this.harmCount = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.phone = new System.Windows.Forms.Label();
            this.middleName = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.surname = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // historyAttentionBackground
            // 
            this.historyAttentionBackground.Location = new System.Drawing.Point(640, 112);
            this.historyAttentionBackground.Name = "historyAttentionBackground";
            this.historyAttentionBackground.Size = new System.Drawing.Size(75, 23);
            this.historyAttentionBackground.TabIndex = 13;
            this.historyAttentionBackground.Text = "История";
            this.historyAttentionBackground.UseVisualStyleBackColor = true;
            this.historyAttentionBackground.Click += new System.EventHandler(this.historyAttentionBackground_Click);
            // 
            // harmCount
            // 
            this.harmCount.Location = new System.Drawing.Point(637, 16);
            this.harmCount.Name = "harmCount";
            this.harmCount.Size = new System.Drawing.Size(78, 13);
            this.harmCount.TabIndex = 12;
            this.harmCount.Text = "Harm";
            this.harmCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.harmCount.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Location = new System.Drawing.Point(23, 122);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(32, 13);
            this.email.TabIndex = 11;
            this.email.Text = "Email";
            this.email.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            // 
            // phone
            // 
            this.phone.AutoSize = true;
            this.phone.Location = new System.Drawing.Point(23, 100);
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(38, 13);
            this.phone.TabIndex = 10;
            this.phone.Text = "Phone";
            this.phone.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            // 
            // middleName
            // 
            this.middleName.AutoSize = true;
            this.middleName.Location = new System.Drawing.Point(23, 61);
            this.middleName.Name = "middleName";
            this.middleName.Size = new System.Drawing.Size(66, 13);
            this.middleName.TabIndex = 9;
            this.middleName.Text = "MiddleName";
            this.middleName.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Location = new System.Drawing.Point(23, 38);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(35, 13);
            this.name.TabIndex = 8;
            this.name.Text = "Name";
            this.name.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            // 
            // surname
            // 
            this.surname.AutoSize = true;
            this.surname.Location = new System.Drawing.Point(23, 16);
            this.surname.Name = "surname";
            this.surname.Size = new System.Drawing.Size(49, 13);
            this.surname.TabIndex = 7;
            this.surname.Text = "Surname";
            this.surname.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            // 
            // EmployeeUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(232)))), ((int)(((byte)(211)))));
            this.Controls.Add(this.historyAttentionBackground);
            this.Controls.Add(this.harmCount);
            this.Controls.Add(this.email);
            this.Controls.Add(this.phone);
            this.Controls.Add(this.middleName);
            this.Controls.Add(this.name);
            this.Controls.Add(this.surname);
            this.Margin = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.Name = "EmployeeUserControl";
            this.Padding = new System.Windows.Forms.Padding(20);
            this.Size = new System.Drawing.Size(738, 150);
            this.Load += new System.EventHandler(this.EmployeeUserControl_Load);
            this.Click += new System.EventHandler(this.EmployeeUserControl_Click);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.EmployeeUserControl_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button historyAttentionBackground;
        private System.Windows.Forms.Label harmCount;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label phone;
        private System.Windows.Forms.Label middleName;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label surname;
    }
}
