﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Work_Starostin.Services;

namespace Work_Starostin_UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// PKGH
        /// Проверка метода CalculateMaterialAmount.
        /// </summary>
        
        [TestMethod]
        public void TestMethod1()
        {
            Assert.AreEqual(PaymentManager.CalculatingPayments(1, 1000000, 200, 10, 1000), 300000);
        }
    }
}
