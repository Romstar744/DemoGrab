﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Work_Starostin.Services
{
    public class PaymentManager
    {
        public static double CalculatingPayments(int id, int income, int days, int durationbusinessTrip, int dailyAllowanceSize)
        {
            double avgIncome = income / days;

            double Accruals = avgIncome * durationbusinessTrip;

            double dailyAllowance = dailyAllowanceSize * days;

            double AllIncome = Accruals + dailyAllowance;

            if (Program.context.HeadOfDepartment.FirstOrDefault(e => e.EmployeeId == id) != null)
            {
                AllIncome *= 1.2;
            }

            return AllIncome;
        }
    }
}
