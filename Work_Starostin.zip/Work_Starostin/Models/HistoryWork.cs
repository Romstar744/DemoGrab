namespace Work_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("HistoryWork")]
    public partial class HistoryWork
    {
        [Key]
        public int IdHistoryWork { get; set; }

        public DateTime? Date { get; set; }

        public int EmployeeId { get; set; }

        public int TypeOfWorkId { get; set; }

        public int WorkingConditionId { get; set; }

        public virtual Employee Employee { get; set; }

        public virtual TypeOfWork TypeOfWork { get; set; }

        public virtual WorkingCondition WorkingCondition { get; set; }
    }
}
