namespace Work_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Linq;
    using Work_Starostin.Services;

    [Table("Employee")]
    public partial class Employee
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Employee()
        {
            HeadOfDepartment = new HashSet<HeadOfDepartment>();
            HistoryWork = new HashSet<HistoryWork>();
        }

        [Key]
        public int IdEmployee { get; set; }

        [StringLength(255)]
        public string Surname { get; set; }

        [StringLength(255)]
        public string Name { get; set; }

        [StringLength(255)]
        public string MiddleName { get; set; }

        public int PositionId { get; set; }

        public int DepartmentId { get; set; }

        [StringLength(255)]
        public string Email { get; set; }

        public double? Phone { get; set; }

        public virtual Department Department { get; set; }

        public virtual Position Position { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HeadOfDepartment> HeadOfDepartment { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HistoryWork> HistoryWork { get; set; }

        private int GetHarmCount()
        {

            DateTime selectedDate = DateStorage.SelectedDate;

            DateTime startOfWeek = selectedDate.AddDays(-(int)selectedDate.DayOfWeek + (selectedDate.DayOfWeek == 0 ? -6 : 1));

            // ����� ������ (������ �����������)
            DateTime endOfWeek = startOfWeek.AddDays(6);

            return Program.context.HistoryWork.Where(e => e.EmployeeId == IdEmployee && e.WorkingConditionId == 3 && e.Date > startOfWeek && e.Date < endOfWeek).ToList().Count();
        }

        public bool isNew()
        {
            return IdEmployee == 0;
        }

        public int HarmCount
        {
            get
            {
                return GetHarmCount();
            }
        }
    }
}
