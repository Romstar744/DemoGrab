namespace Work_Starostin.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("WorkingCondition")]
    public partial class WorkingCondition
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public WorkingCondition()
        {
            HistoryWork = new HashSet<HistoryWork>();
        }

        [Key]
        public int IdWorkingCondition { get; set; }

        [StringLength(255)]
        public string NameWorkingCondition { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<HistoryWork> HistoryWork { get; set; }
    }
}
