using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Work_Starostin.Models
{
    public partial class WorkDb : DbContext
    {
        public WorkDb()
            : base("name=WorkDb")
        {
        }

        public virtual DbSet<Department> Department { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<HeadOfDepartment> HeadOfDepartment { get; set; }
        public virtual DbSet<HistoryWork> HistoryWork { get; set; }
        public virtual DbSet<Position> Position { get; set; }
        public virtual DbSet<TypeOfWork> TypeOfWork { get; set; }
        public virtual DbSet<WorkingCondition> WorkingCondition { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Department>()
                .HasMany(e => e.Employee)
                .WithRequired(e => e.Department)
                .HasForeignKey(e => e.DepartmentId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Employee>()
                .HasMany(e => e.HeadOfDepartment)
                .WithOptional(e => e.Employee)
                .HasForeignKey(e => e.EmployeeId);

            modelBuilder.Entity<Employee>()
                .HasMany(e => e.HistoryWork)
                .WithRequired(e => e.Employee)
                .HasForeignKey(e => e.EmployeeId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Position>()
                .HasMany(e => e.Employee)
                .WithRequired(e => e.Position)
                .HasForeignKey(e => e.PositionId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<TypeOfWork>()
                .HasMany(e => e.HistoryWork)
                .WithRequired(e => e.TypeOfWork)
                .HasForeignKey(e => e.TypeOfWorkId)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<WorkingCondition>()
                .HasMany(e => e.HistoryWork)
                .WithRequired(e => e.WorkingCondition)
                .HasForeignKey(e => e.WorkingConditionId)
                .WillCascadeOnDelete(false);
        }
    }
}
