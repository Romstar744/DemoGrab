﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Work_Starostin.Models;
using Work_Starostin.Services;

namespace Work_Starostin.AppForms
{
    public partial class HistoryForm : Form
    {
        private Employee _employee;
        public HistoryForm(Employee employee)
        {
            InitializeComponent();
            _employee = employee;
            UserExperienceManager.SetTitle(this, $"История работ сотрудника \"{_employee.Surname}\"");
        }

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "work_StarostinDataSet.WorkingCondition". При необходимости она может быть перемещена или удалена.
            this.workingConditionTableAdapter.Fill(this.work_StarostinDataSet.WorkingCondition);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "work_StarostinDataSet.TypeOfWork". При необходимости она может быть перемещена или удалена.
            this.typeOfWorkTableAdapter.Fill(this.work_StarostinDataSet.TypeOfWork);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "work_StarostinDataSet.HistoryWork". При необходимости она может быть перемещена или удалена.
            //this.historyWorkTableAdapter.Fill(this.work_StarostinDataSet.HistoryWork);
            historyWorkBindingSource.DataSource = Program.context.HistoryWork.Where(h => h.EmployeeId == _employee.IdEmployee).ToList();

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
        }
    }
}
