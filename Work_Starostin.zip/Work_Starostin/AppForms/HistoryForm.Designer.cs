﻿namespace Work_Starostin.AppForms
{
    partial class HistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.work_StarostinDataSet = new Work_Starostin.Work_StarostinDataSet();
            this.historyWorkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.historyWorkTableAdapter = new Work_Starostin.Work_StarostinDataSetTableAdapters.HistoryWorkTableAdapter();
            this.tableAdapterManager = new Work_Starostin.Work_StarostinDataSetTableAdapters.TableAdapterManager();
            this.historyWorkDataGridView = new System.Windows.Forms.DataGridView();
            this.typeOfWorkBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.typeOfWorkTableAdapter = new Work_Starostin.Work_StarostinDataSetTableAdapters.TypeOfWorkTableAdapter();
            this.workingConditionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.workingConditionTableAdapter = new Work_Starostin.Work_StarostinDataSetTableAdapters.WorkingConditionTableAdapter();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.work_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyWorkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyWorkDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workingConditionBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Work_Starostin.Properties.Resources.ПАО_АтомПрибор;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.historyWorkDataGridView);
            this.splitContainer.Panel2.Padding = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.splitContainer.Size = new System.Drawing.Size(800, 450);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(85, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(82, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "История работ";
            // 
            // work_StarostinDataSet
            // 
            this.work_StarostinDataSet.DataSetName = "Work_StarostinDataSet";
            this.work_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // historyWorkBindingSource
            // 
            this.historyWorkBindingSource.DataMember = "HistoryWork";
            this.historyWorkBindingSource.DataSource = this.work_StarostinDataSet;
            // 
            // historyWorkTableAdapter
            // 
            this.historyWorkTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DepartmentTableAdapter = null;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.HeadOfDepartmentTableAdapter = null;
            this.tableAdapterManager.HistoryWorkTableAdapter = this.historyWorkTableAdapter;
            this.tableAdapterManager.PositionTableAdapter = null;
            this.tableAdapterManager.TypeOfWorkTableAdapter = this.typeOfWorkTableAdapter;
            this.tableAdapterManager.UpdateOrder = Work_Starostin.Work_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkingConditionTableAdapter = this.workingConditionTableAdapter;
            // 
            // historyWorkDataGridView
            // 
            this.historyWorkDataGridView.AllowUserToAddRows = false;
            this.historyWorkDataGridView.AllowUserToDeleteRows = false;
            this.historyWorkDataGridView.AutoGenerateColumns = false;
            this.historyWorkDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.historyWorkDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.historyWorkDataGridView.DataSource = this.historyWorkBindingSource;
            this.historyWorkDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.historyWorkDataGridView.Location = new System.Drawing.Point(20, 0);
            this.historyWorkDataGridView.Name = "historyWorkDataGridView";
            this.historyWorkDataGridView.ReadOnly = true;
            this.historyWorkDataGridView.Size = new System.Drawing.Size(760, 336);
            this.historyWorkDataGridView.TabIndex = 0;
            // 
            // typeOfWorkBindingSource
            // 
            this.typeOfWorkBindingSource.DataMember = "TypeOfWork";
            this.typeOfWorkBindingSource.DataSource = this.work_StarostinDataSet;
            // 
            // typeOfWorkTableAdapter
            // 
            this.typeOfWorkTableAdapter.ClearBeforeFill = true;
            // 
            // workingConditionBindingSource
            // 
            this.workingConditionBindingSource.DataMember = "WorkingCondition";
            this.workingConditionBindingSource.DataSource = this.work_StarostinDataSet;
            // 
            // workingConditionTableAdapter
            // 
            this.workingConditionTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Date";
            this.dataGridViewTextBoxColumn2.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 239;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "TypeOfWorkId";
            this.dataGridViewTextBoxColumn4.DataSource = this.typeOfWorkBindingSource;
            this.dataGridViewTextBoxColumn4.DisplayMember = "NameTypeOfWork";
            this.dataGridViewTextBoxColumn4.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn4.HeaderText = "Тип работы";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn4.ValueMember = "IdTypeOfWork";
            this.dataGridViewTextBoxColumn4.Width = 239;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "WorkingConditionId";
            this.dataGridViewTextBoxColumn5.DataSource = this.workingConditionBindingSource;
            this.dataGridViewTextBoxColumn5.DisplayMember = "NameWorkingCondition";
            this.dataGridViewTextBoxColumn5.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn5.HeaderText = "Условия труда";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn5.ValueMember = "IdWorkingCondition";
            this.dataGridViewTextBoxColumn5.Width = 239;
            // 
            // HistoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer);
            this.Name = "HistoryForm";
            this.Text = "HistoryForm";
            this.Load += new System.EventHandler(this.HistoryForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.work_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyWorkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.historyWorkDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.typeOfWorkBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workingConditionBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private Work_StarostinDataSet work_StarostinDataSet;
        private System.Windows.Forms.BindingSource historyWorkBindingSource;
        private Work_StarostinDataSetTableAdapters.HistoryWorkTableAdapter historyWorkTableAdapter;
        private Work_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView historyWorkDataGridView;
        private Work_StarostinDataSetTableAdapters.TypeOfWorkTableAdapter typeOfWorkTableAdapter;
        private System.Windows.Forms.BindingSource typeOfWorkBindingSource;
        private Work_StarostinDataSetTableAdapters.WorkingConditionTableAdapter workingConditionTableAdapter;
        private System.Windows.Forms.BindingSource workingConditionBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn5;
    }
}