﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Work_Starostin.CustomControls;
using Work_Starostin.Models;
using Work_Starostin.Services;

namespace Work_Starostin.AppForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            UserExperienceManager.SetTitle(this, "Список сотрудников");
        }
        private void ShowEmployee()
        {
            List<Employee> employees = Program.context.Employee.OrderBy(e => e.Surname).ToList();
            foreach (Employee employee in employees)
            {
                flowLayoutPanel.Controls.Add(new EmployeeUserControl(employee));
            }
        }

        private void ClearPartnerList()
        {
            splitContainer.Panel2.Controls[0].Controls.Clear();
        }

        public void RefreshEmployee()
        {
            ClearPartnerList();
            ShowEmployee();
        }

        private void newEmployeeAttentionBackground_Click(object sender, EventArgs e)
        {
            CreateUpdateEmployeeForm createUpdateEmployee = new CreateUpdateEmployeeForm();
            DialogResult employeeSaves = createUpdateEmployee.ShowDialog();

            if (employeeSaves == DialogResult.OK)
            {
                RefreshEmployee();
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            DateTime today = DateTime.Today;

            DateTime monday = today.AddDays(-(int)today.DayOfWeek + (today.DayOfWeek == 0 ? -6 : 1));

            dateTimePicker.Value = monday;

            ShowEmployee();

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
        }
    }
}
