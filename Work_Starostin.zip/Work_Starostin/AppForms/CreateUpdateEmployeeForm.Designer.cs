﻿namespace Work_Starostin.AppForms
{
    partial class CreateUpdateEmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label surnameLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label middleNameLabel;
            System.Windows.Forms.Label positionIdLabel;
            System.Windows.Forms.Label departmentIdLabel;
            System.Windows.Forms.Label emailLabel;
            System.Windows.Forms.Label phoneLabel;
            this.work_StarostinDataSet = new Work_Starostin.Work_StarostinDataSet();
            this.employeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeTableAdapter = new Work_Starostin.Work_StarostinDataSetTableAdapters.EmployeeTableAdapter();
            this.tableAdapterManager = new Work_Starostin.Work_StarostinDataSetTableAdapters.TableAdapterManager();
            this.positionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.positionTableAdapter = new Work_Starostin.Work_StarostinDataSetTableAdapters.PositionTableAdapter();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter = new Work_Starostin.Work_StarostinDataSetTableAdapters.DepartmentTableAdapter();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SaveAttentionBackground = new System.Windows.Forms.Button();
            this.surnameTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.positionIdComboBox = new System.Windows.Forms.ComboBox();
            this.departmentIdComboBox = new System.Windows.Forms.ComboBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.phoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            surnameLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            middleNameLabel = new System.Windows.Forms.Label();
            positionIdLabel = new System.Windows.Forms.Label();
            departmentIdLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.work_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.positionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // work_StarostinDataSet
            // 
            this.work_StarostinDataSet.DataSetName = "Work_StarostinDataSet";
            this.work_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeBindingSource
            // 
            this.employeeBindingSource.DataMember = "Employee";
            this.employeeBindingSource.DataSource = this.work_StarostinDataSet;
            // 
            // employeeTableAdapter
            // 
            this.employeeTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DepartmentTableAdapter = this.departmentTableAdapter;
            this.tableAdapterManager.EmployeeTableAdapter = this.employeeTableAdapter;
            this.tableAdapterManager.HeadOfDepartmentTableAdapter = null;
            this.tableAdapterManager.HistoryWorkTableAdapter = null;
            this.tableAdapterManager.PositionTableAdapter = this.positionTableAdapter;
            this.tableAdapterManager.TypeOfWorkTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Work_Starostin.Work_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkingConditionTableAdapter = null;
            // 
            // positionBindingSource
            // 
            this.positionBindingSource.DataMember = "Position";
            this.positionBindingSource.DataSource = this.work_StarostinDataSet;
            // 
            // positionTableAdapter
            // 
            this.positionTableAdapter.ClearBeforeFill = true;
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.work_StarostinDataSet;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(surnameLabel);
            this.splitContainer.Panel2.Controls.Add(this.surnameTextBox);
            this.splitContainer.Panel2.Controls.Add(nameLabel);
            this.splitContainer.Panel2.Controls.Add(this.nameTextBox);
            this.splitContainer.Panel2.Controls.Add(middleNameLabel);
            this.splitContainer.Panel2.Controls.Add(this.middleNameTextBox);
            this.splitContainer.Panel2.Controls.Add(positionIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.positionIdComboBox);
            this.splitContainer.Panel2.Controls.Add(departmentIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.departmentIdComboBox);
            this.splitContainer.Panel2.Controls.Add(emailLabel);
            this.splitContainer.Panel2.Controls.Add(this.emailTextBox);
            this.splitContainer.Panel2.Controls.Add(phoneLabel);
            this.splitContainer.Panel2.Controls.Add(this.phoneMaskedTextBox);
            this.splitContainer.Panel2.Controls.Add(this.SaveAttentionBackground);
            this.splitContainer.Size = new System.Drawing.Size(380, 450);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(85, 20);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(101, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Новый сотрудник";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Work_Starostin.Properties.Resources.ПАО_АтомПрибор;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // SaveAttentionBackground
            // 
            this.SaveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SaveAttentionBackground.Location = new System.Drawing.Point(65, 263);
            this.SaveAttentionBackground.Name = "SaveAttentionBackground";
            this.SaveAttentionBackground.Size = new System.Drawing.Size(272, 45);
            this.SaveAttentionBackground.TabIndex = 2;
            this.SaveAttentionBackground.Text = "Сохранить";
            this.SaveAttentionBackground.UseVisualStyleBackColor = true;
            this.SaveAttentionBackground.Click += new System.EventHandler(this.SaveAttentionBackground_Click);
            // 
            // surnameLabel
            // 
            surnameLabel.AutoSize = true;
            surnameLabel.Location = new System.Drawing.Point(60, 43);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new System.Drawing.Size(57, 13);
            surnameLabel.TabIndex = 2;
            surnameLabel.Text = "Фамилия:";
            // 
            // surnameTextBox
            // 
            this.surnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Surname", true));
            this.surnameTextBox.Location = new System.Drawing.Point(148, 40);
            this.surnameTextBox.Name = "surnameTextBox";
            this.surnameTextBox.Size = new System.Drawing.Size(181, 22);
            this.surnameTextBox.TabIndex = 3;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(60, 71);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(32, 13);
            nameLabel.TabIndex = 4;
            nameLabel.Text = "Имя:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(148, 68);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(181, 22);
            this.nameTextBox.TabIndex = 5;
            // 
            // middleNameLabel
            // 
            middleNameLabel.AutoSize = true;
            middleNameLabel.Location = new System.Drawing.Point(60, 99);
            middleNameLabel.Name = "middleNameLabel";
            middleNameLabel.Size = new System.Drawing.Size(67, 13);
            middleNameLabel.TabIndex = 6;
            middleNameLabel.Text = "Отчество:";
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "MiddleName", true));
            this.middleNameTextBox.Location = new System.Drawing.Point(148, 96);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(181, 22);
            this.middleNameTextBox.TabIndex = 7;
            // 
            // positionIdLabel
            // 
            positionIdLabel.AutoSize = true;
            positionIdLabel.Location = new System.Drawing.Point(60, 127);
            positionIdLabel.Name = "positionIdLabel";
            positionIdLabel.Size = new System.Drawing.Size(71, 13);
            positionIdLabel.TabIndex = 8;
            positionIdLabel.Text = "Должность:";
            // 
            // positionIdComboBox
            // 
            this.positionIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.employeeBindingSource, "PositionId", true));
            this.positionIdComboBox.DataSource = this.positionBindingSource;
            this.positionIdComboBox.DisplayMember = "NamePosition";
            this.positionIdComboBox.FormattingEnabled = true;
            this.positionIdComboBox.Location = new System.Drawing.Point(148, 124);
            this.positionIdComboBox.Name = "positionIdComboBox";
            this.positionIdComboBox.Size = new System.Drawing.Size(181, 21);
            this.positionIdComboBox.TabIndex = 9;
            this.positionIdComboBox.ValueMember = "IdPosition";
            // 
            // departmentIdLabel
            // 
            departmentIdLabel.AutoSize = true;
            departmentIdLabel.Location = new System.Drawing.Point(60, 154);
            departmentIdLabel.Name = "departmentIdLabel";
            departmentIdLabel.Size = new System.Drawing.Size(46, 13);
            departmentIdLabel.TabIndex = 10;
            departmentIdLabel.Text = "Отдел:";
            // 
            // departmentIdComboBox
            // 
            this.departmentIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.employeeBindingSource, "DepartmentId", true));
            this.departmentIdComboBox.DataSource = this.departmentBindingSource;
            this.departmentIdComboBox.DisplayMember = "NameDepartment";
            this.departmentIdComboBox.FormattingEnabled = true;
            this.departmentIdComboBox.Location = new System.Drawing.Point(148, 151);
            this.departmentIdComboBox.Name = "departmentIdComboBox";
            this.departmentIdComboBox.Size = new System.Drawing.Size(181, 21);
            this.departmentIdComboBox.TabIndex = 11;
            this.departmentIdComboBox.ValueMember = "IdDepartment";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(60, 181);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(38, 13);
            emailLabel.TabIndex = 12;
            emailLabel.Text = "Email:";
            // 
            // emailTextBox
            // 
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Email", true));
            this.emailTextBox.Location = new System.Drawing.Point(148, 178);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(181, 22);
            this.emailTextBox.TabIndex = 13;
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(60, 209);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(55, 13);
            phoneLabel.TabIndex = 14;
            phoneLabel.Text = "Телефон:";
            // 
            // phoneMaskedTextBox
            // 
            this.phoneMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeeBindingSource, "Phone", true));
            this.phoneMaskedTextBox.Location = new System.Drawing.Point(148, 206);
            this.phoneMaskedTextBox.Mask = "+0 000 000 00 00";
            this.phoneMaskedTextBox.Name = "phoneMaskedTextBox";
            this.phoneMaskedTextBox.Size = new System.Drawing.Size(181, 22);
            this.phoneMaskedTextBox.TabIndex = 15;
            // 
            // CreateUpdateEmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 450);
            this.Controls.Add(this.splitContainer);
            this.Font = new System.Drawing.Font("Segoe UI Semibold", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Name = "CreateUpdateEmployeeForm";
            this.Text = "CreateUpdateEmployeeForm";
            this.Load += new System.EventHandler(this.CreateUpdateEmployeeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.work_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.positionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Work_StarostinDataSet work_StarostinDataSet;
        private System.Windows.Forms.BindingSource employeeBindingSource;
        private Work_StarostinDataSetTableAdapters.EmployeeTableAdapter employeeTableAdapter;
        private Work_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private Work_StarostinDataSetTableAdapters.PositionTableAdapter positionTableAdapter;
        private System.Windows.Forms.BindingSource positionBindingSource;
        private Work_StarostinDataSetTableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox surnameTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.ComboBox positionIdComboBox;
        private System.Windows.Forms.ComboBox departmentIdComboBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.MaskedTextBox phoneMaskedTextBox;
        private System.Windows.Forms.Button SaveAttentionBackground;
    }
}