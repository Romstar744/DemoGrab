﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Work_Starostin.Exceptions;
using Work_Starostin.Models;
using Work_Starostin.Services;

namespace Work_Starostin.AppForms
{
    public partial class CreateUpdateEmployeeForm : Form
    {
        private Employee _employee;
        public CreateUpdateEmployeeForm()
        {
            InitializeComponent();
            _employee = new Employee();
            UserExperienceManager.SetTitle(this, "Новый сотрудник");
        }

        public CreateUpdateEmployeeForm(Employee employee)
        {
            InitializeComponent();
            _employee = employee;
            UserExperienceManager.SetTitle(this, $"Изменить сотрудника: \"{_employee.Surname}\"");
        }

        private void newEmployeeAttentionBackground_Click(object sender, EventArgs e)
        {

        }

        private void CreateUpdateEmployeeForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "work_StarostinDataSet.Department". При необходимости она может быть перемещена или удалена.
            this.departmentTableAdapter.Fill(this.work_StarostinDataSet.Department);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "work_StarostinDataSet.Position". При необходимости она может быть перемещена или удалена.
            this.positionTableAdapter.Fill(this.work_StarostinDataSet.Position);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "work_StarostinDataSet.Employee". При необходимости она может быть перемещена или удалена.
            this.employeeTableAdapter.Fill(this.work_StarostinDataSet.Employee);

            if (!_employee.isNew())
            {
                employeeBindingSource.DataSource = _employee;
            }

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
            UserExperienceManager.CustomizeControls(splitContainer.Panel2.Controls);
        }

        private string GetSanitizedPhone()
        {
            // PKGH            
            // Подготовка введенной пользователем информации
            // о телефоне для сохранения в БД.

            string trimmedPhone = phoneMaskedTextBox.Text.Replace("+", "");
            trimmedPhone = trimmedPhone.Replace(" ", "");
            return trimmedPhone;
        }

        private void FillModelFields()
        {
            _employee.Surname = surnameTextBox.Text;
            _employee.Name = nameTextBox.Text;
            _employee.MiddleName = middleNameTextBox.Text;
            _employee.PositionId = (int)positionIdComboBox.SelectedValue;
            _employee.DepartmentId = (int)departmentIdComboBox.SelectedValue;
            _employee.Email = emailTextBox.Text;
            _employee.Phone = Int64.Parse(GetSanitizedPhone());
        }

        /// <summary>
        /// PKGH
        /// Проверка введенной пользователем информации. Если допущена ошибка,
        /// сообщить, в каком поле это случилось, и что можно вводить.
        /// </summary>
        /// <param name="pattern">Паттерн</param>
        /// <param name="userInputText">Текст, введенный пользователем в поле на форме.</param>
        /// <param name="field">Поле, в котором пользователь допустил ошибку.</param>
        /// <param name="messageAboutAllowedSymbols">Какие символы разрешено вводить в это поле.</param>
        /// <exception cref="ValidationException"></exception>
        private void ValidateGeneral(string userInputText, string field, string messageAboutAllowedSymbols = "поле не должно быть пустым.", string pattern = @"^.+$")
        {
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
            bool isValid = regex.IsMatch(userInputText.Trim());
            if (!isValid)
            {
                throw new ValidationException($"{field}: {messageAboutAllowedSymbols}");
            }
        }

        private void ValidateEmployeeName()
        {
            ValidateGeneral(nameTextBox.Text, "Наименование");
        }

        private void ValidateEmployeeSurname()
        {
            ValidateGeneral(surnameTextBox.Text, "Наименование");
        }
        private void ValidateEmployeeMiddleName()
        {
            ValidateGeneral(middleNameTextBox.Text, "Наименование");
        }
        private void ValidatePhone()
        {
            ValidateGeneral(GetSanitizedPhone(), "Телефон", "должно быть 11 цифр.", @"^\d{11}$");
        }
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            try
            {
                // Normalize the domain
                email = Regex.Replace(email, @"(@)(.+)$", DomainMapper,
                                      RegexOptions.None, TimeSpan.FromMilliseconds(200));

                // Examines the domain part of the email and normalizes it.
                string DomainMapper(Match match)
                {
                    // Use IdnMapping class to convert Unicode domain names.
                    var idn = new IdnMapping();

                    // Pull out and process domain name (throws ArgumentException on invalid)
                    string domainName = idn.GetAscii(match.Groups[2].Value);

                    return match.Groups[1].Value + domainName;
                }
            }
            catch (RegexMatchTimeoutException e)
            {
                return false;
            }
            catch (ArgumentException e)
            {
                return false;
            }

            try
            {
                return Regex.IsMatch(email,
                    @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        private void ValidateEmail()
        {
            if (!IsValidEmail(emailTextBox.Text.Trim()))
            {
                throw new ValidationException("Неверный формат электронной почты");
            }
        }


        private void Validate()
        {
            ValidateEmployeeName();
            ValidateEmployeeSurname();
            ValidateEmployeeMiddleName();
            ValidatePhone();
            ValidateEmail();
        }

        private void SaveAttentionBackground_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            FillModelFields();

            DialogResult toBeSaved = MessageBox.Show("Сохранить?", "Запрос подтверждения", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (toBeSaved == DialogResult.No)
            {
                return;
            }

            if (_employee.isNew())
            {
                Program.context.Employee.Add(_employee);
            }

            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
