﻿namespace MasterPol_Starostin.AppForms
{
    partial class CreateUpdatePartnerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label partnerNameLabel;
            System.Windows.Forms.Label partnerTypeIdLabel;
            System.Windows.Forms.Label ratingLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label ceoLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label emailLabel;
            this.productTableAdapter1 = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.ProductTableAdapter();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.partnerNameTextBox = new System.Windows.Forms.TextBox();
            this.partnerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterPol_StarostinDataSet = new MasterPol_Starostin.MasterPol_StarostinDataSet();
            this.partnerTypeIdComboBox = new System.Windows.Forms.ComboBox();
            this.partnerTypeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ratingTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.ceoTextBox = new System.Windows.Forms.TextBox();
            this.phoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.ratingHintAttentionFont = new System.Windows.Forms.Label();
            this.saveAttentionBackground = new System.Windows.Forms.Button();
            this.partnerTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.partnersTableAdapter = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.PartnerTableAdapter();
            this.tableAdapterManager = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.TableAdapterManager();
            this.partnerTypeTableAdapter = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.PartnerTypeTableAdapter();
            partnerNameLabel = new System.Windows.Forms.Label();
            partnerTypeIdLabel = new System.Windows.Forms.Label();
            ratingLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            ceoLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterPol_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // partnerNameLabel
            // 
            partnerNameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            partnerNameLabel.AutoSize = true;
            partnerNameLabel.Location = new System.Drawing.Point(49, 45);
            partnerNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            partnerNameLabel.Name = "partnerNameLabel";
            partnerNameLabel.Size = new System.Drawing.Size(89, 13);
            partnerNameLabel.TabIndex = 15;
            partnerNameLabel.Text = "Наименование";
            // 
            // partnerTypeIdLabel
            // 
            partnerTypeIdLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            partnerTypeIdLabel.AutoSize = true;
            partnerTypeIdLabel.Location = new System.Drawing.Point(49, 71);
            partnerTypeIdLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            partnerTypeIdLabel.Name = "partnerTypeIdLabel";
            partnerTypeIdLabel.Size = new System.Drawing.Size(26, 13);
            partnerTypeIdLabel.TabIndex = 17;
            partnerTypeIdLabel.Text = "Тип";
            // 
            // ratingLabel
            // 
            ratingLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            ratingLabel.AutoSize = true;
            ratingLabel.Location = new System.Drawing.Point(49, 98);
            ratingLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            ratingLabel.Name = "ratingLabel";
            ratingLabel.Size = new System.Drawing.Size(51, 13);
            ratingLabel.TabIndex = 19;
            ratingLabel.Text = "Рейтинг";
            // 
            // addressLabel
            // 
            addressLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(49, 138);
            addressLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(40, 13);
            addressLabel.TabIndex = 21;
            addressLabel.Text = "Адрес";
            // 
            // ceoLabel
            // 
            ceoLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            ceoLabel.AutoSize = true;
            ceoLabel.Location = new System.Drawing.Point(49, 164);
            ceoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            ceoLabel.Name = "ceoLabel";
            ceoLabel.Size = new System.Drawing.Size(61, 13);
            ceoLabel.TabIndex = 23;
            ceoLabel.Text = "Директор";
            // 
            // phoneLabel
            // 
            phoneLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(49, 190);
            phoneLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(54, 13);
            phoneLabel.TabIndex = 25;
            phoneLabel.Text = "Телефон";
            // 
            // emailLabel
            // 
            emailLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(49, 216);
            emailLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(40, 13);
            emailLabel.TabIndex = 27;
            emailLabel.Text = "Почта";
            // 
            // productTableAdapter1
            // 
            this.productTableAdapter1.ClearBeforeFill = true;
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(partnerNameLabel);
            this.splitContainer.Panel2.Controls.Add(this.partnerNameTextBox);
            this.splitContainer.Panel2.Controls.Add(partnerTypeIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.partnerTypeIdComboBox);
            this.splitContainer.Panel2.Controls.Add(ratingLabel);
            this.splitContainer.Panel2.Controls.Add(this.ratingTextBox);
            this.splitContainer.Panel2.Controls.Add(addressLabel);
            this.splitContainer.Panel2.Controls.Add(this.addressTextBox);
            this.splitContainer.Panel2.Controls.Add(ceoLabel);
            this.splitContainer.Panel2.Controls.Add(this.ceoTextBox);
            this.splitContainer.Panel2.Controls.Add(phoneLabel);
            this.splitContainer.Panel2.Controls.Add(this.phoneMaskedTextBox);
            this.splitContainer.Panel2.Controls.Add(emailLabel);
            this.splitContainer.Panel2.Controls.Add(this.emailTextBox);
            this.splitContainer.Panel2.Controls.Add(this.ratingHintAttentionFont);
            this.splitContainer.Panel2.Controls.Add(this.saveAttentionBackground);
            this.splitContainer.Panel2.Padding = new System.Windows.Forms.Padding(23, 0, 23, 20);
            this.splitContainer.Size = new System.Drawing.Size(390, 406);
            this.splitContainer.SplitterDistance = 81;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(99, 20);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(102, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "НОВЫЙ ПАРТНЕР";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MasterPol_Starostin.Properties.Resources.Мастер_пол;
            this.pictureBox1.Location = new System.Drawing.Point(23, 20);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // partnerNameTextBox
            // 
            this.partnerNameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.partnerNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "PartnerName", true));
            this.partnerNameTextBox.Location = new System.Drawing.Point(153, 42);
            this.partnerNameTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.partnerNameTextBox.Name = "partnerNameTextBox";
            this.partnerNameTextBox.Size = new System.Drawing.Size(140, 22);
            this.partnerNameTextBox.TabIndex = 16;
            // 
            // partnerBindingSource
            // 
            this.partnerBindingSource.DataMember = "Partner";
            this.partnerBindingSource.DataSource = this.masterPol_StarostinDataSet;
            // 
            // masterPol_StarostinDataSet
            // 
            this.masterPol_StarostinDataSet.DataSetName = "MasterPol_StarostinDataSet";
            this.masterPol_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // partnerTypeIdComboBox
            // 
            this.partnerTypeIdComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.partnerTypeIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.partnerBindingSource, "PartnerTypeId", true));
            this.partnerTypeIdComboBox.DataSource = this.partnerTypeBindingSource1;
            this.partnerTypeIdComboBox.DisplayMember = "PartnerTypeName";
            this.partnerTypeIdComboBox.FormattingEnabled = true;
            this.partnerTypeIdComboBox.Location = new System.Drawing.Point(153, 68);
            this.partnerTypeIdComboBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.partnerTypeIdComboBox.Name = "partnerTypeIdComboBox";
            this.partnerTypeIdComboBox.Size = new System.Drawing.Size(140, 21);
            this.partnerTypeIdComboBox.TabIndex = 18;
            this.partnerTypeIdComboBox.ValueMember = "IdPartnerType";
            // 
            // partnerTypeBindingSource1
            // 
            this.partnerTypeBindingSource1.DataMember = "PartnerType";
            this.partnerTypeBindingSource1.DataSource = this.masterPol_StarostinDataSet;
            // 
            // ratingTextBox
            // 
            this.ratingTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ratingTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Rating", true));
            this.ratingTextBox.Location = new System.Drawing.Point(153, 95);
            this.ratingTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.ratingTextBox.Name = "ratingTextBox";
            this.ratingTextBox.Size = new System.Drawing.Size(140, 22);
            this.ratingTextBox.TabIndex = 20;
            // 
            // addressTextBox
            // 
            this.addressTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Address", true));
            this.addressTextBox.Location = new System.Drawing.Point(153, 138);
            this.addressTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(140, 22);
            this.addressTextBox.TabIndex = 22;
            // 
            // ceoTextBox
            // 
            this.ceoTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ceoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Ceo", true));
            this.ceoTextBox.Location = new System.Drawing.Point(153, 164);
            this.ceoTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.ceoTextBox.Name = "ceoTextBox";
            this.ceoTextBox.Size = new System.Drawing.Size(140, 22);
            this.ceoTextBox.TabIndex = 24;
            // 
            // phoneMaskedTextBox
            // 
            this.phoneMaskedTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.phoneMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Phone", true));
            this.phoneMaskedTextBox.Location = new System.Drawing.Point(153, 190);
            this.phoneMaskedTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.phoneMaskedTextBox.Mask = "+0 000 000 00 00";
            this.phoneMaskedTextBox.Name = "phoneMaskedTextBox";
            this.phoneMaskedTextBox.Size = new System.Drawing.Size(140, 22);
            this.phoneMaskedTextBox.TabIndex = 26;
            // 
            // emailTextBox
            // 
            this.emailTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Email", true));
            this.emailTextBox.Location = new System.Drawing.Point(153, 216);
            this.emailTextBox.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(140, 22);
            this.emailTextBox.TabIndex = 28;
            // 
            // ratingHintAttentionFont
            // 
            this.ratingHintAttentionFont.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ratingHintAttentionFont.AutoSize = true;
            this.ratingHintAttentionFont.Location = new System.Drawing.Point(120, 118);
            this.ratingHintAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.ratingHintAttentionFont.Name = "ratingHintAttentionFont";
            this.ratingHintAttentionFont.Size = new System.Drawing.Size(177, 13);
            this.ratingHintAttentionFont.TabIndex = 15;
            this.ratingHintAttentionFont.Text = "Целое неотрицательное число";
            // 
            // saveAttentionBackground
            // 
            this.saveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.saveAttentionBackground.Location = new System.Drawing.Point(52, 244);
            this.saveAttentionBackground.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.saveAttentionBackground.Name = "saveAttentionBackground";
            this.saveAttentionBackground.Size = new System.Drawing.Size(293, 44);
            this.saveAttentionBackground.TabIndex = 14;
            this.saveAttentionBackground.Text = "Сохранить";
            this.saveAttentionBackground.UseVisualStyleBackColor = true;
            this.saveAttentionBackground.Click += new System.EventHandler(this.saveAttentionBackground_Click);
            // 
            // partnerTypeBindingSource
            // 
            this.partnerTypeBindingSource.DataMember = "PartnerType";
            this.partnerTypeBindingSource.DataSource = this.masterPol_StarostinDataSet;
            // 
            // partnersTableAdapter
            // 
            this.partnersTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Material_typeTableAdapter = null;
            this.tableAdapterManager.PartnerProductTableAdapter = null;
            this.tableAdapterManager.PartnerTableAdapter = this.partnersTableAdapter;
            this.tableAdapterManager.PartnerTypeTableAdapter = null;
            this.tableAdapterManager.ProductTableAdapter = null;
            this.tableAdapterManager.ProductTypeTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // partnerTypeTableAdapter
            // 
            this.partnerTypeTableAdapter.ClearBeforeFill = true;
            // 
            // CreateUpdatePartnerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 406);
            this.Controls.Add(this.splitContainer);
            this.Margin = new System.Windows.Forms.Padding(5, 3, 5, 3);
            this.Name = "CreateUpdatePartnerForm";
            this.Text = "CreateUpdatePartnerForm";
            this.Load += new System.EventHandler(this.CreateUpdatePartnerForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterPol_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MasterPol_StarostinDataSet masterPol_StarostinDataSet;
        private MasterPol_StarostinDataSetTableAdapters.PartnerTableAdapter partnersTableAdapter;
        private MasterPol_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button saveAttentionBackground;
        private System.Windows.Forms.Label ratingHintAttentionFont;
        private System.Windows.Forms.BindingSource partnerTypeBindingSource;
        private MasterPol_StarostinDataSetTableAdapters.PartnerTypeTableAdapter partnerTypeTableAdapter;
        private MasterPol_StarostinDataSetTableAdapters.ProductTableAdapter productTableAdapter1;
        private System.Windows.Forms.BindingSource partnerBindingSource;
        private System.Windows.Forms.TextBox partnerNameTextBox;
        private System.Windows.Forms.ComboBox partnerTypeIdComboBox;
        private System.Windows.Forms.TextBox ratingTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox ceoTextBox;
        private System.Windows.Forms.MaskedTextBox phoneMaskedTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.BindingSource partnerTypeBindingSource1;
    }
}