﻿namespace MasterPol_Starostin.AppForms
{
    partial class CreateUpdatePartnerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label partnerNameLabel;
            System.Windows.Forms.Label partnerTypeIdLabel;
            System.Windows.Forms.Label ratingLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label ceoLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label emailLabel;
            this.productTableAdapter1 = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.ProductTableAdapter();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.partnerNameTextBox = new System.Windows.Forms.TextBox();
            this.partnerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.masterPol_StarostinDataSet = new MasterPol_Starostin.MasterPol_StarostinDataSet();
            this.partnerTypeIdComboBox = new System.Windows.Forms.ComboBox();
            this.partnerTypeBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ratingTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.ceoTextBox = new System.Windows.Forms.TextBox();
            this.phoneMaskedTextBox = new System.Windows.Forms.MaskedTextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.ratingHintAttentionFont = new System.Windows.Forms.Label();
            this.saveAttentionBackground = new System.Windows.Forms.Button();
            this.partnerTypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.partnersTableAdapter = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.PartnerTableAdapter();
            this.tableAdapterManager = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.TableAdapterManager();
            this.partnerTypeTableAdapter = new MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.PartnerTypeTableAdapter();
            partnerNameLabel = new System.Windows.Forms.Label();
            partnerTypeIdLabel = new System.Windows.Forms.Label();
            ratingLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            ceoLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterPol_StarostinDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // partnerNameLabel
            // 
            partnerNameLabel.AutoSize = true;
            partnerNameLabel.Location = new System.Drawing.Point(324, 19);
            partnerNameLabel.Name = "partnerNameLabel";
            partnerNameLabel.Size = new System.Drawing.Size(83, 13);
            partnerNameLabel.TabIndex = 15;
            partnerNameLabel.Text = "Наименование";
            // 
            // partnerTypeIdLabel
            // 
            partnerTypeIdLabel.AutoSize = true;
            partnerTypeIdLabel.Location = new System.Drawing.Point(324, 45);
            partnerTypeIdLabel.Name = "partnerTypeIdLabel";
            partnerTypeIdLabel.Size = new System.Drawing.Size(26, 13);
            partnerTypeIdLabel.TabIndex = 17;
            partnerTypeIdLabel.Text = "Тип";
            // 
            // ratingLabel
            // 
            ratingLabel.AutoSize = true;
            ratingLabel.Location = new System.Drawing.Point(324, 72);
            ratingLabel.Name = "ratingLabel";
            ratingLabel.Size = new System.Drawing.Size(48, 13);
            ratingLabel.TabIndex = 19;
            ratingLabel.Text = "Рейтинг";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(324, 112);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(38, 13);
            addressLabel.TabIndex = 21;
            addressLabel.Text = "Адрес";
            // 
            // ceoLabel
            // 
            ceoLabel.AutoSize = true;
            ceoLabel.Location = new System.Drawing.Point(324, 138);
            ceoLabel.Name = "ceoLabel";
            ceoLabel.Size = new System.Drawing.Size(57, 13);
            ceoLabel.TabIndex = 23;
            ceoLabel.Text = "Директор";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(324, 164);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(52, 13);
            phoneLabel.TabIndex = 25;
            phoneLabel.Text = "Телефон";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(324, 190);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(37, 13);
            emailLabel.TabIndex = 27;
            emailLabel.Text = "Почта";
            // 
            // productTableAdapter1
            // 
            this.productTableAdapter1.ClearBeforeFill = true;
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(partnerNameLabel);
            this.splitContainer.Panel2.Controls.Add(this.partnerNameTextBox);
            this.splitContainer.Panel2.Controls.Add(partnerTypeIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.partnerTypeIdComboBox);
            this.splitContainer.Panel2.Controls.Add(ratingLabel);
            this.splitContainer.Panel2.Controls.Add(this.ratingTextBox);
            this.splitContainer.Panel2.Controls.Add(addressLabel);
            this.splitContainer.Panel2.Controls.Add(this.addressTextBox);
            this.splitContainer.Panel2.Controls.Add(ceoLabel);
            this.splitContainer.Panel2.Controls.Add(this.ceoTextBox);
            this.splitContainer.Panel2.Controls.Add(phoneLabel);
            this.splitContainer.Panel2.Controls.Add(this.phoneMaskedTextBox);
            this.splitContainer.Panel2.Controls.Add(emailLabel);
            this.splitContainer.Panel2.Controls.Add(this.emailTextBox);
            this.splitContainer.Panel2.Controls.Add(this.ratingHintAttentionFont);
            this.splitContainer.Panel2.Controls.Add(this.saveAttentionBackground);
            this.splitContainer.Panel2.Padding = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.splitContainer.Size = new System.Drawing.Size(800, 450);
            this.splitContainer.SplitterDistance = 90;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(85, 20);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(102, 13);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "НОВЫЙ ПАРТНЕР";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::MasterPol_Starostin.Properties.Resources.Мастер_пол;
            this.pictureBox1.Location = new System.Drawing.Point(20, 20);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // partnerNameTextBox
            // 
            this.partnerNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "PartnerName", true));
            this.partnerNameTextBox.Location = new System.Drawing.Point(413, 16);
            this.partnerNameTextBox.Name = "partnerNameTextBox";
            this.partnerNameTextBox.Size = new System.Drawing.Size(121, 20);
            this.partnerNameTextBox.TabIndex = 16;
            // 
            // partnerBindingSource
            // 
            this.partnerBindingSource.DataMember = "Partner";
            this.partnerBindingSource.DataSource = this.masterPol_StarostinDataSet;
            // 
            // masterPol_StarostinDataSet
            // 
            this.masterPol_StarostinDataSet.DataSetName = "MasterPol_StarostinDataSet";
            this.masterPol_StarostinDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // partnerTypeIdComboBox
            // 
            this.partnerTypeIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.partnerBindingSource, "PartnerTypeId", true));
            this.partnerTypeIdComboBox.DataSource = this.partnerTypeBindingSource1;
            this.partnerTypeIdComboBox.DisplayMember = "PartnerTypeName";
            this.partnerTypeIdComboBox.FormattingEnabled = true;
            this.partnerTypeIdComboBox.Location = new System.Drawing.Point(413, 42);
            this.partnerTypeIdComboBox.Name = "partnerTypeIdComboBox";
            this.partnerTypeIdComboBox.Size = new System.Drawing.Size(121, 21);
            this.partnerTypeIdComboBox.TabIndex = 18;
            this.partnerTypeIdComboBox.ValueMember = "IdPartnerType";
            // 
            // partnerTypeBindingSource1
            // 
            this.partnerTypeBindingSource1.DataMember = "PartnerType";
            this.partnerTypeBindingSource1.DataSource = this.masterPol_StarostinDataSet;
            // 
            // ratingTextBox
            // 
            this.ratingTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Rating", true));
            this.ratingTextBox.Location = new System.Drawing.Point(413, 69);
            this.ratingTextBox.Name = "ratingTextBox";
            this.ratingTextBox.Size = new System.Drawing.Size(121, 20);
            this.ratingTextBox.TabIndex = 20;
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Address", true));
            this.addressTextBox.Location = new System.Drawing.Point(413, 112);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(121, 20);
            this.addressTextBox.TabIndex = 22;
            // 
            // ceoTextBox
            // 
            this.ceoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Ceo", true));
            this.ceoTextBox.Location = new System.Drawing.Point(413, 138);
            this.ceoTextBox.Name = "ceoTextBox";
            this.ceoTextBox.Size = new System.Drawing.Size(121, 20);
            this.ceoTextBox.TabIndex = 24;
            // 
            // phoneMaskedTextBox
            // 
            this.phoneMaskedTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Phone", true));
            this.phoneMaskedTextBox.Location = new System.Drawing.Point(413, 164);
            this.phoneMaskedTextBox.Mask = "+0 000 000 00 00";
            this.phoneMaskedTextBox.Name = "phoneMaskedTextBox";
            this.phoneMaskedTextBox.Size = new System.Drawing.Size(121, 20);
            this.phoneMaskedTextBox.TabIndex = 26;
            // 
            // emailTextBox
            // 
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.partnerBindingSource, "Email", true));
            this.emailTextBox.Location = new System.Drawing.Point(413, 190);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(121, 20);
            this.emailTextBox.TabIndex = 28;
            // 
            // ratingHintAttentionFont
            // 
            this.ratingHintAttentionFont.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ratingHintAttentionFont.AutoSize = true;
            this.ratingHintAttentionFont.Location = new System.Drawing.Point(410, 92);
            this.ratingHintAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.ratingHintAttentionFont.Name = "ratingHintAttentionFont";
            this.ratingHintAttentionFont.Size = new System.Drawing.Size(162, 13);
            this.ratingHintAttentionFont.TabIndex = 15;
            this.ratingHintAttentionFont.Text = "Целое неотрицательное число";
            // 
            // saveAttentionBackground
            // 
            this.saveAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.saveAttentionBackground.Location = new System.Drawing.Point(233, 231);
            this.saveAttentionBackground.Name = "saveAttentionBackground";
            this.saveAttentionBackground.Size = new System.Drawing.Size(354, 44);
            this.saveAttentionBackground.TabIndex = 14;
            this.saveAttentionBackground.Text = "Сохранить";
            this.saveAttentionBackground.UseVisualStyleBackColor = true;
            this.saveAttentionBackground.Click += new System.EventHandler(this.saveAttentionBackground_Click);
            // 
            // partnerTypeBindingSource
            // 
            this.partnerTypeBindingSource.DataMember = "PartnerType";
            this.partnerTypeBindingSource.DataSource = this.masterPol_StarostinDataSet;
            // 
            // partnersTableAdapter
            // 
            this.partnersTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Material_typeTableAdapter = null;
            this.tableAdapterManager.PartnerProductTableAdapter = null;
            this.tableAdapterManager.PartnerTableAdapter = this.partnersTableAdapter;
            this.tableAdapterManager.PartnerTypeTableAdapter = null;
            this.tableAdapterManager.ProductTableAdapter = null;
            this.tableAdapterManager.ProductTypeTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = MasterPol_Starostin.MasterPol_StarostinDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // partnerTypeTableAdapter
            // 
            this.partnerTypeTableAdapter.ClearBeforeFill = true;
            // 
            // CreateUpdatePartnerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateUpdatePartnerForm";
            this.Text = "CreateUpdatePartnerForm";
            this.Load += new System.EventHandler(this.CreateUpdatePartnerForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.masterPol_StarostinDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.partnerTypeBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MasterPol_StarostinDataSet masterPol_StarostinDataSet;
        private MasterPol_StarostinDataSetTableAdapters.PartnerTableAdapter partnersTableAdapter;
        private MasterPol_StarostinDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button saveAttentionBackground;
        private System.Windows.Forms.Label ratingHintAttentionFont;
        private System.Windows.Forms.BindingSource partnerTypeBindingSource;
        private MasterPol_StarostinDataSetTableAdapters.PartnerTypeTableAdapter partnerTypeTableAdapter;
        private MasterPol_StarostinDataSetTableAdapters.ProductTableAdapter productTableAdapter1;
        private System.Windows.Forms.BindingSource partnerBindingSource;
        private System.Windows.Forms.TextBox partnerNameTextBox;
        private System.Windows.Forms.ComboBox partnerTypeIdComboBox;
        private System.Windows.Forms.TextBox ratingTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox ceoTextBox;
        private System.Windows.Forms.MaskedTextBox phoneMaskedTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.BindingSource partnerTypeBindingSource1;
    }
}