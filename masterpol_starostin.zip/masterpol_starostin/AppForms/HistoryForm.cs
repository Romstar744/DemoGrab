﻿using MasterPol_Starostin.Models;
using MasterPol_Starostin.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MasterPol_Starostin.AppForms
{
    public partial class HistoryForm : ParentForm
    {
        private Partner _partner;
        public HistoryForm(Partner partner)
        {
            InitializeComponent();
            _partner = partner;
            UserExperienceManager.SetTitle(this, $"История продаж компании \"{_partner.PartnerName}\"");
        }

        

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "masterPol_StarostinDataSet.Products". При необходимости она может быть перемещена или удалена.
            this.productsTableAdapter.Fill(this.masterPol_StarostinDataSet.Product);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "masterPol_StarostinDataSet.Partner_products". При необходимости она может быть перемещена или удалена.
            this.partner_productsTableAdapter.Fill(this.masterPol_StarostinDataSet.PartnerProduct);

            partner_productsBindingSource.DataSource = Program.context.PartnerProduct.
                Where(p => p.PartnerId == _partner.IdPartner).OrderByDescending(p => p.Date).ToList();

            UserExperienceManager.CustomizeControls(splitContainer.Panel1.Controls);
        }
    }
}
